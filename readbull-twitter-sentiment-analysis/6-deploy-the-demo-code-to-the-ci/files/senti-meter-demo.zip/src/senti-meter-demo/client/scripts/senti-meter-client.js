"use strict";
/// <reference path="../../../scripts/websocket-client.ts" />
class SentimeterClient {
    static MinRotationAngle = -70;
    static MaxRotationAngle = 70;
    static Middle = 0;
    rotationAngle = SentimeterClient.Middle;
    sentimentQueue = [];
    socket;
    maxReconnectAttempts = 3;
    intervalId;
    constructor() {
        this.socket = new WebSocketClient({
            address: 'localhost',
            port: 9000
        });
    }
    async start() {
        try {
            clearInterval(this.intervalId);
            await this.connect();
            this.intervalId = setInterval(this.handleTick, 100);
        }
        catch (e) {
            console.log('Cannot connect to server', e);
        }
    }
    async connect() {
        await this.socket.connect();
        this.setupSocket();
        console.log('Connected...');
    }
    setupSocket() {
        this.socket.addEventListener('message', this.handleMessage);
        this.socket.addEventListener('close', this.reconnect);
        this.socket.addEventListener('error', this.reconnect);
    }
    rotateLeft() {
        this.rotationAngle--;
        if (this.rotationAngle < SentimeterClient.MinRotationAngle) {
            this.rotationAngle = SentimeterClient.MinRotationAngle;
            return;
        }
        this.rotateToCurrentAngle();
    }
    rotateRight() {
        this.rotationAngle++;
        if (this.rotationAngle >= SentimeterClient.MaxRotationAngle) {
            this.rotationAngle = SentimeterClient.MaxRotationAngle;
            return;
        }
        this.rotateToCurrentAngle();
    }
    rotateToCurrentAngle() {
        const animation = document.getElementById('rotate');
        animation.setAttribute('transform', `rotate(${this.rotationAngle} 150 180)`);
    }
    handleMessage = (message) => {
        if (!message.data) {
            return;
        }
        const sentiments = message.data.split(',');
        this.sentimentQueue.push(...sentiments);
    };
    handleTick = () => {
        const sentiment = this.sentimentQueue.pop();
        if (!sentiment) {
            return;
        }
        console.log(sentiment);
        switch (sentiment) {
            case 'positive':
                this.rotateRight();
                break;
            case 'negative':
                this.rotateLeft();
                break;
        }
    };
    reconnect = async () => {
        try {
            console.log('Disconnected, attempting reconnection');
            this.assertReconnectAttempt();
            await this.start();
        }
        catch (e) {
            console.log(`Could not reconnect to server`);
        }
    };
    assertReconnectAttempt() {
        if (this.maxReconnectAttempts-- <= 0) {
            throw new Error('Last reconnection attempt exhausted');
        }
    }
}
document.addEventListener('DOMContentLoaded', async () => {
    const sentiMeterClient = new SentimeterClient();
    await sentiMeterClient.start();
});
