/// <reference path="../../../scripts/websocket-client.ts" />

class SentimeterClient {
  private static readonly MinRotationAngle = -70;
  private static readonly MaxRotationAngle = 70;
  private static readonly Middle = 0;

  private rotationAngle = SentimeterClient.Middle;
  private sentimentQueue: string[] = [];
  private socket: WebSocketClient;
  private maxReconnectAttempts = 3;
  private intervalId: any;

  constructor() {
    this.socket = new WebSocketClient({
      address: 'localhost',
      port: 9000
    });
  }

  public async start() {
    try {
      clearInterval(this.intervalId);
      await this.connect();
      this.intervalId = setInterval(this.handleTick, 100);
    } catch (e) {
      console.log('Cannot connect to server', e);
    }
  }

  private async connect() {
    await this.socket.connect();
    this.setupSocket();
    console.log('Connected...');
  }

  private setupSocket() {
    this.socket.addEventListener('message', this.handleMessage);
    this.socket.addEventListener('close', this.reconnect);
    this.socket.addEventListener('error', this.reconnect);
  }

  private rotateLeft() {
    this.rotationAngle--;

    if (this.rotationAngle < SentimeterClient.MinRotationAngle) {
      this.rotationAngle = SentimeterClient.MinRotationAngle;
      return;
    }

    this.rotateToCurrentAngle();
  }

  private rotateRight() {
    this.rotationAngle++;

    if (this.rotationAngle >= SentimeterClient.MaxRotationAngle) {
      this.rotationAngle = SentimeterClient.MaxRotationAngle;
      return;
    }

    this.rotateToCurrentAngle();
  }

  private rotateToCurrentAngle() {
    const animation: Element = document.getElementById('rotate')!;
    animation.setAttribute('transform', `rotate(${this.rotationAngle} 150 180)`);
  }

  private handleMessage = (message: MessageEvent<string>) => {
    if (!message.data) {
      return;
    }

    const sentiments: string[] = message.data.split(',');
    this.sentimentQueue.push(...sentiments);
  }

  private handleTick = () => {
    const sentiment: string | undefined = this.sentimentQueue.pop();

    if (!sentiment) {
      return;
    }

    console.log(sentiment);

    switch (sentiment) {
      case 'positive':

        this.rotateRight();
        break;

      case 'negative':

        this.rotateLeft();
        break;
    }
  }

  private reconnect = async () => {
    try {
      console.log('Disconnected, attempting reconnection');
      this.assertReconnectAttempt();
      await this.start();
    } catch (e) {
      console.log(`Could not reconnect to server`);
    }
  }

  private assertReconnectAttempt() {
    if (this.maxReconnectAttempts-- <= 0) {
      throw new Error('Last reconnection attempt exhausted');
    }
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const sentiMeterClient = new SentimeterClient();
  await sentiMeterClient.start();
});