/// <reference path="../../../scripts/html.ts" />

interface ImageOptimalDimensions {
  maxWidth: number;
  maxHeight: number;
}

class SelfOptimizingImage {
  private imageElement!: HTMLImageElement;

  constructor(
    private imageParentElement: HTMLImageElement,
    private sizeReferenceElement: HTMLElement,
    imageSrc: string
  ) {
    this.createImage(imageSrc);
  }

  public destroy() {
    this.imageElement.remove();
  }

  private createImage(src: string) {
    this.imageElement = Html.create(
      'img', {
        src,
        style: {
          display: 'none'
        }
      },
      this.imageParentElement
    );

    this.imageElement.addEventListener('load', this.renderImage);
    window.addEventListener('resize', this.renderImage);
  }

  private renderImage = () => {
    const { maxWidth, maxHeight } = this.getOptimalImageDimensions();

    this.imageElement.style.maxWidth = Html.toPx(maxWidth);
    this.imageElement.style.maxHeight = Html.toPx(maxHeight);
    this.imageElement.style.display = 'block';
  }

  private getOptimalImageDimensions(): ImageOptimalDimensions {
    const areaPadding = Html.getElementPadding(this.sizeReferenceElement) * 2;

    return {
      maxWidth: (this.sizeReferenceElement.clientWidth * 0.7) - areaPadding,
      maxHeight: this.sizeReferenceElement.clientHeight - areaPadding
    };
  }
}