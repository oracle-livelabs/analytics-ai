"use strict";
class WebSocketClient {
    parameters;
    static MaxConnectionRetries = 5;
    static ReconnectionMinDelayMs = 100;
    webSocket;
    connectionRetryNum = 0;
    constructor(parameters) {
        this.parameters = parameters;
    }
    async connect() {
        await this.tryConnectWithRetries();
    }
    addEventListener(messageType, handler) {
        if (!this.webSocket) {
            throw new Error('Cannot add event listeners until socket is connected');
        }
        this.webSocket.addEventListener(messageType, handler);
    }
    async tryConnectWithRetries() {
        for (this.connectionRetryNum = 1; this.connectionRetryNum <= WebSocketClient.MaxConnectionRetries; this.connectionRetryNum++) {
            try {
                await this.asyncConnection();
                this.connectionRetryNum = 0;
                return;
            }
            catch (e) {
                await this.handleNextConnectionAttempt();
            }
        }
    }
    async asyncConnection() {
        return new Promise((resolve, reject) => {
            this.tryConnect(resolve, reject);
        });
    }
    tryConnect(onSuccess, onFail) {
        const { address, port } = this.parameters;
        this.webSocket = new WebSocket(`wss://${address}:${port}`);
        this.webSocket.onopen = onSuccess;
        this.webSocket.onerror = onFail;
    }
    async handleNextConnectionAttempt() {
        this.assertNextConnectionAttempt();
        const delayValue = this.getDelayValue();
        await this.delay(delayValue);
    }
    assertNextConnectionAttempt() {
        if (this.connectionRetryNum >= WebSocketClient.MaxConnectionRetries) {
            throw new Error('Could not connect');
        }
    }
    delay(delayTimeMs) {
        return new Promise(resolve => setTimeout(resolve, delayTimeMs));
    }
    getDelayValue() {
        const exponentialBackOff = (2 ** this.connectionRetryNum);
        const randomAdditionalDelay = Math.round(Math.random() * WebSocketClient.ReconnectionMinDelayMs);
        return (exponentialBackOff * WebSocketClient.ReconnectionMinDelayMs) + randomAdditionalDelay;
    }
}
