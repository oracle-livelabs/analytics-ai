interface BatchLimitsRecord {
  recordCount: number;
  perRecordCharacterCount: number;
  batchCharacterCount: number;
}

export enum LanguageAnalysisBufferAppendCode {
  InvalidRecord,
  LimitExceeded
};

export class LanguageAnalysisBatchBuffer {
  private static readonly MaxRecordsPerBatch = 100;
  private static readonly MaxCharactersPerPerRecord = 5000;
  private static readonly MaxCharactersPerBatch = 20000;

  private texts: string[] = [];
  private batchLimitsRecord: BatchLimitsRecord = LanguageAnalysisBatchBuffer.getBatchLimitsRecord();

  public append(text: string) {
    this.assertNewTextFitsInBatch(text);
    this.texts.push(text);
    this.updateBatchLimitsRecordAfterAppend(text.length);
  }

  public flushBuffer(): string[] {
    const tempTexts: string[] = this.texts;
    this.texts = [];
    this.batchLimitsRecord = LanguageAnalysisBatchBuffer.getBatchLimitsRecord();

    return tempTexts;
  }

  private assertNewTextFitsInBatch(text: string) {
    if (!text?.length) {
      throw LanguageAnalysisBufferAppendCode.InvalidRecord;
    }

    if (this.batchLimitsRecord.perRecordCharacterCount < text.length) {
      throw LanguageAnalysisBufferAppendCode.InvalidRecord;
    }

    if (this.batchLimitsRecord.recordCount - 1 < 0) {
      throw LanguageAnalysisBufferAppendCode.LimitExceeded;
    }

    if (this.batchLimitsRecord.batchCharacterCount - text.length < 0) {
      throw LanguageAnalysisBufferAppendCode.LimitExceeded;
    }
  }

  private updateBatchLimitsRecordAfterAppend(textLength: number) {
    this.batchLimitsRecord.recordCount--;
    this.batchLimitsRecord.batchCharacterCount -= textLength;
  }

  private static getBatchLimitsRecord(): BatchLimitsRecord {
    return {
      recordCount: LanguageAnalysisBatchBuffer.MaxRecordsPerBatch,
      perRecordCharacterCount: LanguageAnalysisBatchBuffer.MaxCharactersPerPerRecord,
      batchCharacterCount: LanguageAnalysisBatchBuffer.MaxCharactersPerBatch
    };
  }
}