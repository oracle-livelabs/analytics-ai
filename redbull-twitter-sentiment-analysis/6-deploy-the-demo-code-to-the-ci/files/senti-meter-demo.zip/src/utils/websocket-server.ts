import { createServer, Server } from 'https';
import { readFile } from 'fs/promises';
import { WebSocketServer as WSWebSocketServer, WebSocket } from 'ws';

export interface CertificateInfo {
  certificateFilePath: string;
  keyFilePath: string;
}

export interface WebSocketServerParameters {
  port: number;
  address: string;
  certificate: CertificateInfo;
}

export class WebSocketServer {
  private httpsServer!: Server;
  private webSocketServer!: WSWebSocketServer;

  constructor(private options: WebSocketServerParameters) {
  }

  public async start() {
    await this.createHttpsServer();
    this.listen();
    this.webSocketServer = new WSWebSocketServer({ server: this.httpsServer });
  }

  public send(data: any): void {
    if (typeof data !== 'string') {
      data = JSON.stringify(data);
    }

    this.webSocketServer.clients.forEach((webSocket: WebSocket) => {
      webSocket.send(data);
    });
  }

  public sendObject(data: object) {
    this.webSocketServer.clients.forEach((webSocket: WebSocket) => {
      webSocket.send(data);
    });
  }

  private async createHttpsServer() {
    const { certificate: { certificateFilePath, keyFilePath } } = this.options;
    this.httpsServer = createServer({
      cert: await readFile(certificateFilePath),
      key: await readFile(keyFilePath)
    });
  }

  private listen() {
    const { port, address } = this.options;
    this.httpsServer.listen(port, address);
    console.log(`The WebSocket server is listening on ${address}:${port}`);
  }
}