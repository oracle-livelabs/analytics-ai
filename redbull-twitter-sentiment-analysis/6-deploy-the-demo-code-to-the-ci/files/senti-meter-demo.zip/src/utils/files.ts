import * as fs from 'fs';
import path from 'path';

type FileCallback = (fileInfo: FileInfo) => Promise<void>;

export interface FileInfo {
  fullPath: string;
  createTime: number;
}

export default class Files {
  public static async exists(path: string): Promise<boolean> {
    try {
      await fs.promises.access(path, fs.constants.F_OK);
      return true;
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code === 'ENOENT') {
        return false;
      }

      throw e;
    }
  }

  public static async mkDirIfNotExists(path: string) {
    if (!await Files.exists(path)) {
      await fs.promises.mkdir(path);    
    }
  }

  public static async processFiles(rootDir: string, fileCallback: FileCallback) {
    const files: FileInfo[] = await Files.getCreationTimeSortedFilesListForDir(`${rootDir}`);

    for (const file of files) {
      await fileCallback(file);
    }
  }

  public static async getFilesInDir(rootDirFullPath: string): Promise<string[]> {
    return await fs.promises.readdir(rootDirFullPath);
  }

  public static async getFilesInfoInDir(rootDirFullPath: string): Promise<FileInfo[]> {
    const dirs: string[] = await Files.getFilesInDir(rootDirFullPath);
    return dirs.map((name: string) => Files.getFileInfo(`${rootDirFullPath}/${name}`));
  }

  public static async getCreationTimeSortedFilesListForDir(rootDirFullPath: string): Promise<FileInfo[]> {
    const dirsWithCreateTime: FileInfo[] = await Files.getFilesInfoInDir(rootDirFullPath);

    return dirsWithCreateTime.sort(
      (file1: FileInfo, file2: FileInfo) => file1.createTime - file2.createTime
    );
  }

  public static async getNewestFileInDir(dir: string): Promise<FileInfo | undefined> {
    const files: FileInfo[] = await Files.getCreationTimeSortedFilesListForDir(dir);
    return files.shift();
  }

  public static async getOldestFileInDir(dir: string): Promise<FileInfo | undefined> {
    const files: FileInfo[] = await Files.getCreationTimeSortedFilesListForDir(dir);
    return files.pop();
  }

  public static getLastDirName(filePath: string) {
    return path.basename(path.dirname(filePath));
  }

  private static getFileInfo(fileFullPath: string): FileInfo {
    const fullPath = fileFullPath;
    
    return {
      fullPath,
      createTime: fs.statSync(fullPath).mtime.getTime()
    };
  }
}