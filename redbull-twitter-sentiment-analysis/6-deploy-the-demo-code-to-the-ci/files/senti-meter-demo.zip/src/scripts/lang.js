"use strict";
class Lang {
    static deepAssign(source, dest) {
        for (const propertyName in source) {
            const propertyValue = source[propertyName];
            if (propertyValue === undefined) {
                continue;
            }
            if (typeof propertyValue === 'object') {
                if (dest[propertyName] === undefined) {
                    dest[propertyName] = {};
                }
                Lang.deepAssign(propertyValue, dest[propertyName]);
            }
            else {
                dest[propertyName] = propertyValue;
            }
        }
    }
    static debounce(callback, delayMs) {
        let timeoutId = setTimeout(callback, delayMs);
        return () => {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(callback, delayMs);
        };
    }
}
