"use strict";
/// <reference path="./lang.ts" />
class Html {
    static get(selector) {
        return document.querySelector(selector);
    }
    static create(tagName, properties, parent) {
        const element = document.createElement(tagName);
        Lang.deepAssign(properties, element);
        if (parent) {
            parent.appendChild(element);
        }
        return element;
    }
    static remove(selector, parent) {
        if (!parent) {
            parent = document;
        }
        const elements = parent.querySelectorAll(selector);
        for (const element of elements) {
            element.remove();
        }
    }
    static clear(element) {
        while (element.hasChildNodes()) {
            element.firstChild.remove();
        }
    }
    remToPx(remValue) {
        return parseFloat(getComputedStyle(document.documentElement).fontSize) * remValue;
    }
    static toPx(pxValue) {
        return `${pxValue}px`;
    }
    static getElementPadding(element) {
        const padding = getComputedStyle(element).padding;
        return parseFloat(padding);
    }
}
