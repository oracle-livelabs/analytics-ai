interface WebSocketClientParameters {
  address: string;
  port: number;
}

class WebSocketClient {
  private static readonly MaxConnectionRetries = 5;
  private static readonly ReconnectionMinDelayMs = 100;
  private webSocket: WebSocket | undefined;
  private connectionRetryNum = 0;

  constructor(private parameters: WebSocketClientParameters) {
  }

  async connect() {
    await this.tryConnectWithRetries();
  }

  addEventListener<K extends keyof WebSocketEventMap>(
    messageType: K,
    handler: (this: WebSocket, ev: WebSocketEventMap[K]) => void
  ) {
    if (!this.webSocket) {
      throw new Error('Cannot add event listeners until socket is connected');
    }

    this.webSocket.addEventListener(messageType, handler);
  }

  private async tryConnectWithRetries() {
    for (this.connectionRetryNum = 1; this.connectionRetryNum <= WebSocketClient.MaxConnectionRetries; this.connectionRetryNum++) {
      try {
        await this.asyncConnection();
        this.connectionRetryNum = 0;
        return;
      }
      catch (e) {
        await this.handleNextConnectionAttempt();
      }
    }
  }

  private async asyncConnection() {
    return new Promise<void>((resolve, reject) => {
      this.tryConnect(resolve, reject);
    });
  }

  private tryConnect(onSuccess: () => void, onFail: () => void) {
    const { address, port } = this.parameters;
    this.webSocket = new WebSocket(`wss://${address}:${port}`);
    this.webSocket.onopen = onSuccess;
    this.webSocket.onerror = onFail;
  }

  private async handleNextConnectionAttempt() {
    this.assertNextConnectionAttempt();
    const delayValue: number = this.getDelayValue();
    await this.delay(delayValue);
  }

  private assertNextConnectionAttempt() {
    if (this.connectionRetryNum >= WebSocketClient.MaxConnectionRetries) {
      throw new Error('Could not connect');
    }
  }

  private delay(delayTimeMs: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, delayTimeMs));
  }

  private getDelayValue() {
    const exponentialBackOff = (2 ** this.connectionRetryNum);
    const randomAdditionalDelay = Math.round(Math.random() * WebSocketClient.ReconnectionMinDelayMs);
    return (exponentialBackOff * WebSocketClient.ReconnectionMinDelayMs) + randomAdditionalDelay;
  }
}