/// <reference path="./lang.ts" />

type RecursivePartial<T> = Partial<{ [P in keyof T]: RecursivePartial<T[P]> }>;
type Queryable = {
  querySelectorAll<E extends Element = Element>(selectors: string): NodeListOf<E>;
}

class Html {
  public static get<E extends Element = Element>(selector: string): E | null {
    return document.querySelector(selector);
  }

  public static create<K extends keyof HTMLElementTagNameMap>(
    tagName: K,
    properties: RecursivePartial<HTMLElementTagNameMap[K]>,
    parent?: HTMLElement
  ): HTMLElementTagNameMap[K] {
    const element: HTMLElementTagNameMap[K] = document.createElement(tagName);
    Lang.deepAssign(properties, element);

    if (parent) {
      parent.appendChild(element);
    }

    return element;
  }

  public static remove(selector: string, parent?: Queryable) {
    if (!parent) {
      parent = document;
    }

    const elements: NodeListOf<Element> = parent.querySelectorAll(selector);

    for (const element of elements) {
      element.remove();
    }
  }

  public static clear(element: Element) {
    while (element.hasChildNodes()) {
      element.firstChild!.remove();
    }
  }

  public remToPx(remValue: number): number {
    return parseFloat(getComputedStyle(document.documentElement).fontSize) * remValue;
  }

  public static toPx(pxValue: number): string {
    return `${pxValue}px`;
  }

  public static getElementPadding(element: HTMLElement): number {
    const padding: string = getComputedStyle(element).padding;
    return parseFloat(padding);
  }
}