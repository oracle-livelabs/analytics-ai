class Lang {
  public static deepAssign<T>(source: Partial<T>, dest: T) {
    for (const propertyName in source) {
      const propertyValue = source[propertyName];

      if (propertyValue === undefined) {
        continue;
      }

      if (typeof propertyValue === 'object') {
        if (dest[propertyName] === undefined) {
          dest[propertyName] = <any>{};
        }

        Lang.deepAssign(propertyValue!, dest[propertyName]!);
      } else {
        dest[propertyName] = propertyValue!;
      }
    }
  }

  public static debounce(callback: () => void, delayMs: number): () => void {
    let timeoutId = setTimeout(callback, delayMs);

    return () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(callback, delayMs);
    }
  }
}