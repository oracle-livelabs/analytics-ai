import 'dotenv/config';

import * as common from 'oci-common';
import * as aiLanguage from 'oci-ailanguage';

export class LanguageAiApi {
  private static readonly MaximumTextLength = 5000;

  private provider: common.ConfigFileAuthenticationDetailsProvider;
  private client: aiLanguage.AIServiceLanguageClient;

  constructor() {
    this.provider = new common.ConfigFileAuthenticationDetailsProvider(process.env.OCI_AUTH_DIR);
    this.client = new aiLanguage.AIServiceLanguageClient({
      authenticationDetailsProvider: this.provider,
    });
  }

  public async analyzeText(texts: string[]): Promise<string[]> {
    if (!texts || typeof texts !== 'object' || texts.length === 0) {
      throw new Error('Provided text is empty or invalid')
    }

    try {
      const sentiment: aiLanguage.responses.BatchDetectLanguageSentimentsResponse = await this.detectLanguageSentiments(texts);
      return sentiment.batchDetectLanguageSentimentsResult.documents.map(
        (sentimentResults: aiLanguage.models.SentimentDocumentResult) => sentimentResults.documentSentiment || '');
    } catch (error) {
      throw new Error(`An error occured while analyzing language: ${JSON.stringify(error)}`);
    }
  }

  private detectLanguageSentiments(
    texts: string[],
  ): Promise<aiLanguage.responses.BatchDetectLanguageSentimentsResponse> {
    const documents: aiLanguage.models.SentimentsDocument[] = texts.map((text: string, index: number) => ({
      key: `doc${index}`,
      text,
      languageCode: 'en'
    }));

    const batchDetectLanguageSentimentsDetails: aiLanguage.models.BatchDetectLanguageSentimentsDetails = {
      documents
    };

    const batchDetectLanguageSentimentsRequest: aiLanguage.requests.BatchDetectLanguageSentimentsRequest = {
      level: [ aiLanguage.requests.BatchDetectLanguageSentimentsRequest.Level.Sentence ],
      batchDetectLanguageSentimentsDetails
    };

    return this.client.batchDetectLanguageSentiments(batchDetectLanguageSentimentsRequest);
  }
}