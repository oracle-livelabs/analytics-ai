import 'dotenv/config';

import * as common from 'oci-common';
import * as aiVision from 'oci-aivision';

export class VisionAiApi {
  private client: aiVision.AIServiceVisionClient;

  constructor() {
    const provider: common.ConfigFileAuthenticationDetailsProvider = new common.ConfigFileAuthenticationDetailsProvider(process.env.OCI_AUTH_DIR);
    this.client = new aiVision.AIServiceVisionClient({ authenticationDetailsProvider: provider });
  }

  public async analyzeImage(imageDataBase64: string): Promise<aiVision.responses.AnalyzeImageResponse> {
    if (!imageDataBase64 || imageDataBase64.length === 0) {
      throw new Error('Provided image array is empty or invalid')
    }

    try {
      return await this.analyze(imageDataBase64);
    } catch (error) {
      throw new Error(`An error occurred while analyzing language: ${JSON.stringify(error)}`);
    }
  }

  private async analyze(
    imageDataBase64: string
  ): Promise<aiVision.responses.AnalyzeImageResponse> {
    const analyzeImageDetails: aiVision.models.AnalyzeImageDetails = {
      features: [
        <aiVision.models.ImageClassificationFeature>{
          featureType: 'OBJECT_DETECTION',
          maxResults: 100,
        },
        <aiVision.models.ImageTextDetectionFeature>{
          featureType: 'TEXT_DETECTION',
          maxResults: 100,
        },
        <aiVision.models.ImageClassificationFeature>{
          featureType: 'IMAGE_CLASSIFICATION',
          maxResults: 10,
        },
      ],
      image: {
        source: 'INLINE',
        data: imageDataBase64,
      },
    };

    const analyzeImageRequest: aiVision.requests.AnalyzeImageRequest = {
      analyzeImageDetails,
    };

    return await this.client.analyzeImage(analyzeImageRequest);
  }
}