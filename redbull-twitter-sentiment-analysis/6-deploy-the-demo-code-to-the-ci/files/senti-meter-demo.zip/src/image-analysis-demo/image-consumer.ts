import 'dotenv/config';

import fs from 'fs/promises';
import path from 'path';
import fetch from 'node-fetch';

import { Client } from 'twitter-api-sdk';
import { tweetsRecentSearch, TwitterResponse } from 'twitter-api-sdk/dist/types';

import Files from '../utils/files';

let maxImages = 300;

(async function main() {
  const client = new Client(process.env.TWITTER_BEARER_TOKEN!);
  let nextToken: string | undefined = undefined;

  Files.mkDirIfNotExists('./images/');

  do {
    const recentTweetsSearchResults: TwitterResponse<tweetsRecentSearch> = await client.tweets.tweetsRecentSearch({
      query: process.env.IMAGE_QUERY!,
      expansions: ['attachments.media_keys'],
      'media.fields': ['media_key', 'type', 'url'],
      max_results: 100,
      next_token: nextToken
    });

    nextToken = recentTweetsSearchResults?.meta?.next_token;

    if (!recentTweetsSearchResults.includes?.media) {
      break;
    }

    for (const media of recentTweetsSearchResults.includes.media) {
      if (media.type === 'photo') {
        const photoUrl = (<any>media).url;
        const photoExtension = path.extname(photoUrl);
        const photoFullFileName = `./images/${media.media_key}${photoExtension}`;
        console.log(`Downloading ${photoFullFileName}`);

        const response = await fetch(photoUrl);
        const photoBytes = new Uint8Array(await response.arrayBuffer());
        console.log('Saving photo...');
        await fs.writeFile(photoFullFileName, photoBytes);

        if (--maxImages <= 0) {
          break;
        }
      }
    };
  } while (nextToken?.length && maxImages > 0);
})();