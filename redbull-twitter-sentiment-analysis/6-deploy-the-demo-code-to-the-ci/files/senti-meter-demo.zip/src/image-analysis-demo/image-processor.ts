import 'dotenv/config';
import { promises as fs } from 'fs';
import path from 'path';

import * as aiVision from 'oci-aivision';

import { VisionAiApi } from '../oci-apis/vision-ai';
import { WebSocketServer } from '../utils/websocket-server';
import Files from '../utils/files';

interface BoundingBox {
  top: number;
  left: number;
  width: number;
  height: number;
}

interface AnalyzedObject {
  text: string;
  coordinates: BoundingBox;
}

interface AnalyzedImage {
  objects: AnalyzedObject[];
  textLines: AnalyzedObject[];
  classifications: AnalyzedObject[];
}

interface ImageInfo {
  analyzedImage: AnalyzedImage;
  imageDataBase64: string;
}

class ImageProcessor {
  private static readonly ImageProcessingIntervalMs = 1000;
  private static readonly ImagesDir = './images';
  private static readonly MaxImagesPerProcessingBatch = 5;

  private imagesQueue: string[] = [];
  private webSocketsServer: WebSocketServer;
  private visionAi = new VisionAiApi();

  constructor() {
    this.webSocketsServer = new WebSocketServer({
      port: parseInt(process.env.PROCESSOR_SERVER_PORT!),
      address: process.env.LISTEN_ADDRESS!,
      certificate: {
        certificateFilePath: process.env.CERT_FILE!,
        keyFilePath: process.env.KEY_FILE!,
      }
    });
  }

  public async start() {
    await this.webSocketsServer.start();
    await this.startImageProcessing();
  }

  public async startImageProcessing() {
    await this.loadImagesQueue();
    await this.startImageProcessingInterval();
  }

  private async loadImagesQueue() {
    const filesInFolder: string[] = await Files.getFilesInDir(ImageProcessor.ImagesDir);
    this.imagesQueue = filesInFolder.filter(fileName => fileName.toLocaleLowerCase().endsWith('.jpg'));
    console.log(`Loaded ${this.imagesQueue.length} images from the queue`);
  }

  private async startImageProcessingInterval() {
    setTimeout(this.processImages, ImageProcessor.ImageProcessingIntervalMs);
  }

  private processImages = async () => {
    const numImagesToProcess = Math.round(Math.random() * (ImageProcessor.MaxImagesPerProcessingBatch - 1)) + 1;
    console.log(`Processing ${numImagesToProcess} images`);

    try {
      await this.processBatch(numImagesToProcess);

      if (this.imagesQueue.length === 0) {
        await this.loadImagesQueue();
      }
    } catch (e) {
      console.log(e);
    }

    await this.startImageProcessingInterval();
  }

  private async processBatch(numImagesToProcess: number) {
    const imageProcessingTasks: Promise<ImageInfo>[] = [];

    for (let i = 0; i < numImagesToProcess; i++) {
      const imageProcessingTask: Promise<ImageInfo> = this.processNextImage();
      imageProcessingTasks.push(imageProcessingTask);
    }

    const processedImagesInfo: PromiseSettledResult<ImageInfo>[] = await Promise.allSettled(imageProcessingTasks);
    const successfulResults: PromiseSettledResult<ImageInfo>[] = processedImagesInfo.filter(results => results.status === 'fulfilled');
    const imageInfos: ImageInfo[] = successfulResults.map(value => (<PromiseFulfilledResult<ImageInfo>>value).value);
    this.webSocketsServer.send(imageInfos);
  }

  private async processNextImage(): Promise<ImageInfo> {
    const nextImageFullPath: string | undefined = this.imagesQueue.pop();

    if (!nextImageFullPath) {
      throw new Error('Queue empty');
    }

    const imageFileExtension: string = ImageProcessor.getImageExtension(nextImageFullPath);
    const imageDataBase64: string = await this.loadImageDataBase64(nextImageFullPath);
    const analyzedImage: AnalyzedImage = await this.analyzeImage(imageDataBase64);

    return {
      analyzedImage,
      imageDataBase64: `data:image/${imageFileExtension};base64,${imageDataBase64}`
    };
  }

  private static getImageExtension(imageFullPath: string): string {
    const imageFileExtension: string = path.extname(imageFullPath);
    const imageFileExtensionDotRemoved = imageFileExtension.substring(1);
    return imageFileExtensionDotRemoved.toLocaleLowerCase();
  }

  private async loadImageDataBase64(imageFullPath: string): Promise<string> {
    const imageData: Buffer = await fs.readFile(`${ImageProcessor.ImagesDir}/${imageFullPath}`);
    return imageData.toString('base64');
  }

  private async analyzeImage(imageDataBase64: string): Promise<AnalyzedImage> {
    const analyzeImageResponse: aiVision.responses.AnalyzeImageResponse = await this.visionAi.analyzeImage(imageDataBase64);
    return ImageProcessor.analyzeImageResponseToImageInfo(analyzeImageResponse.analyzeImageResult);
  }

  private static analyzeImageResponseToImageInfo(analyzeImageResult: aiVision.models.AnalyzeImageResult): AnalyzedImage {
    return <AnalyzedImage>{
      objects: ImageProcessor.imageObjectsToDetectedObjects(analyzeImageResult.imageObjects),
      textLines: ImageProcessor.imageTextToTextLines(analyzeImageResult.imageText?.lines),
      classifications: ImageProcessor.labelsToClassifications(analyzeImageResult.labels)
    }
  }

  private static imageObjectsToDetectedObjects(imageObjects: aiVision.models.ImageObject[] | undefined): AnalyzedObject[] | undefined {
    return imageObjects?.map<AnalyzedObject>(
      (imageObject: aiVision.models.ImageObject) => (<AnalyzedObject>{
        text: imageObject.name,
        coordinates: ImageProcessor.normalizedVerticesToBoundingBox(imageObject.boundingPolygon.normalizedVertices)
      })
    );
  }

  private static normalizedVerticesToBoundingBox(normalizedVertices: aiVision.models.NormalizedVertex[]): BoundingBox {
    let minX = Number.MAX_SAFE_INTEGER;
    let minY = Number.MAX_SAFE_INTEGER;
    let maxX = Number.MIN_SAFE_INTEGER;
    let maxY = Number.MIN_SAFE_INTEGER;

    for (const vertex of normalizedVertices) {
      if (vertex.x > maxX) {
        maxX = vertex.x;
      }

      if (vertex.y > maxY) {
        maxY = vertex.y;
      }

      if (vertex.x < minX) {
        minX = vertex.x;
      }

      if (vertex.y < minY) {
        minY = vertex.y;
      }
    }

    return <BoundingBox>{
      top: minY * 100,
      left: minX * 100,
      width: (maxX - minX) * 100,
      height: (maxY - minY) * 100
    };
  }

  private static imageTextToTextLines(imageTextLines: aiVision.models.Line[] | undefined): AnalyzedObject[] | undefined {
    return imageTextLines?.map<AnalyzedObject>(
      (imageTextLine: aiVision.models.Line) => (<AnalyzedObject>{
        text: imageTextLine.text,
        coordinates: ImageProcessor.normalizedVerticesToBoundingBox(imageTextLine.boundingPolygon.normalizedVertices)
      })
    );
  }

  private static labelsToClassifications(labels: aiVision.models.Label[] | undefined): AnalyzedObject[] | undefined {
    return labels?.map<AnalyzedObject>(
      (label: aiVision.models.Label) => (<AnalyzedObject>{
        text: label.name,
      })
    );
  }
}

(async function main() {
  const imageProcessor = new ImageProcessor();
  await imageProcessor.start();
})();