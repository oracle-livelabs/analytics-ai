"use strict";
/// <reference path="../../../scripts/websocket-client.ts" />
class ImageAnalysisDemo {
    maxReconnectAttempts = 3;
    image;
    imageContainer = Html.get('#image-container');
    contentTemplate;
    objectCounter = new Counter(Html.get('#object-counts'));
    textCounter = new Counter(Html.get('#text-counts'));
    lightBox = new LightBox();
    socket = new WebSocketClient({
        address: 'localhost',
        port: 9000
    });
    async start() {
        try {
            await this.connect();
        }
        catch (e) {
            console.log('Cannot connect to server', e);
        }
    }
    async connect() {
        await this.socket.connect();
        this.setupSocket();
        console.log('Connected...');
    }
    setupSocket() {
        this.socket.addEventListener('message', this.handleMessage);
        this.socket.addEventListener('close', this.reconnect);
        this.socket.addEventListener('error', this.reconnect);
    }
    handleMessage = (message) => {
        if (!message.data) {
            return;
        }
        const receivedImages = JSON.parse(message.data);
        this.handleReceivedImages(receivedImages);
    };
    handleReceivedImages(receivedImages) {
        receivedImages.forEach(this.handleReceivedImage);
    }
    handleReceivedImage = (receivedImage) => {
        const htmlImage = Html.create('img', {
            src: receivedImage.imageDataBase64
        }, this.imageContainer);
        this.setupImageUi(htmlImage, receivedImage);
    };
    setupImageUi(htmlImage, imageInfo) {
        this.objectCounter.update(imageInfo.analyzedImage.objects);
        this.textCounter.update(ImageAnalysisDemo.filterTextLine(imageInfo.analyzedImage.textLines));
        htmlImage.addEventListener('click', () => this.showImageDetails(imageInfo));
    }
    showImageDetails(imageInfo) {
        this.setupLightBoxContent(imageInfo);
        this.lightBox.show(this.contentTemplate);
    }
    setupLightBoxContent(imageInfo) {
        this.contentTemplate = Html.get('#lightbox-template')?.firstElementChild?.cloneNode(true);
        this.getTemplateElement('lightbox-close-button').addEventListener('click', this.lightBox.hide);
        if (this.image !== undefined) {
            this.image.destroy();
        }
        this.image = new SelfOptimizingImage(this.getTemplateElement('lightbox-image-wrapper'), this.contentTemplate, imageInfo.imageDataBase64);
        this.fillAllItems(imageInfo.analyzedImage);
    }
    getTemplateElement(className) {
        return this.contentTemplate.getElementsByClassName(className)[0];
    }
    fillAllItems(analyzedImage) {
        this.fillItems('lightbox-objects', analyzedImage.objects, true);
        this.fillItems('lightbox-text', analyzedImage.textLines, false);
        this.fillItems('lightbox-classifications', analyzedImage.classifications, false);
    }
    fillItems(parentElementSelector, items, sortAndCoalesce) {
        const parentElement = this.getTemplateElement(parentElementSelector);
        if (!items || items.length === 0) {
            parentElement.style.display = 'none';
            return;
        }
        this.appendItems(parentElement, items, sortAndCoalesce);
    }
    appendItems(parentElement, items, sortAndCoalesce) {
        if (sortAndCoalesce) {
            this.appendCoalescedItems(parentElement, items);
        }
        else {
            this.appendItemsOriginalOrder(parentElement, items);
        }
    }
    appendCoalescedItems(parentElement, items) {
        const itemMap = ImageAnalysisDemo.coalesceItems(items);
        const itemTexts = Object.keys(itemMap);
        itemTexts.forEach((itemText) => {
            this.createItemElement(parentElement, itemText, itemMap[itemText]);
        });
    }
    appendItemsOriginalOrder(parentElement, items) {
        items.forEach((item) => {
            this.createItemElement(parentElement, item.text, [item.coordinates]);
        });
    }
    static coalesceItems(items) {
        const itemMap = {};
        items.forEach((item) => {
            if (itemMap[item.text] === undefined) {
                itemMap[item.text] = [];
            }
            itemMap[item.text].push(item.coordinates);
        });
        return itemMap;
    }
    createItemElement(parentElement, textContent, boundingBoxes) {
        const itemElement = Html.create('div', { textContent }, parentElement);
        this.setupBoundingBoxesForItem(itemElement, boundingBoxes);
    }
    setupBoundingBoxesForItem(itemElement, boundingBoxes) {
        if (boundingBoxes) {
            itemElement.addEventListener('click', () => this.showBoundingBoxes(boundingBoxes));
            itemElement.addEventListener('mouseover', () => this.showBoundingBoxes(boundingBoxes));
            itemElement.addEventListener('mouseout', this.hideBoundingBoxes);
        }
    }
    showBoundingBoxes(boundingBoxes) {
        this.hideBoundingBoxes();
        const imageWrapper = this.getTemplateElement('lightbox-image-wrapper');
        boundingBoxes.forEach((boundingBox) => {
            if (boundingBox) {
                const boundingBoxElement = ImageAnalysisDemo.createBoundingBoxElement(boundingBox);
                imageWrapper.appendChild(boundingBoxElement);
            }
        });
    }
    static createBoundingBoxElement(boundingBox) {
        return Html.create('div', {
            className: 'bounding-box',
            style: {
                top: `${boundingBox.top}%`,
                left: `${boundingBox.left}%`,
                width: `${boundingBox.width}%`,
                height: `${boundingBox.height}%`
            }
        });
    }
    hideBoundingBoxes = () => {
        const imageWrapper = this.getTemplateElement('lightbox-image-wrapper');
        Html.remove('.bounding-box', imageWrapper);
    };
    static filterTextLine(textLines) {
        return textLines.filter((textLine) => /^[a-z ]{2,}$/i.test(textLine.text));
    }
    reconnect = async () => {
        try {
            console.log('Disconnected, attempting reconnection');
            this.assertReconnectAttempt();
            await this.start();
        }
        catch (e) {
            console.log(`Could not reconnect to server`);
        }
    };
    assertReconnectAttempt() {
        if (this.maxReconnectAttempts-- <= 0) {
            throw new Error('Last reconnection attempt exhausted');
        }
    }
}
document.addEventListener('DOMContentLoaded', async () => {
    const imageAnalysisDemo = new ImageAnalysisDemo();
    await imageAnalysisDemo.start();
});
