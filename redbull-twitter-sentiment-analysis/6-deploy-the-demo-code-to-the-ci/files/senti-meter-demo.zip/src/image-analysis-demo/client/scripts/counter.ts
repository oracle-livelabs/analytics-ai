type ObjectCounts = {
  [objectName: string]: number;
}

type ObjectTuple = {
  name: string;
  count: number;
}

class Counter {
  private objects: ObjectCounts = {};

  constructor(private container: HTMLDivElement) { }

  public update(objects: AnalyzedObject[]) {
    if (!objects) {
      return;
    }

    for (const object of objects) {
      this.updateObject(object);
    }

    this.render();
  }

  private updateObject = (object: AnalyzedObject) => {
    if (!this.objects[object.text]) {
      this.objects[object.text] = 0;
    }

    this.objects[object.text]++;
  }

  private render() {
    Html.clear(this.container);
    const sortedObjects: ObjectTuple[] = this.getObjectsSortedByCount();

    for (const object of sortedObjects) {
      if (object.count < 2) {
        continue;
      }

      this.renderObject(object);
    }
  }

  private getObjectsSortedByCount(): ObjectTuple[] {
    const sortArray: ObjectTuple[] = [];

    for (const name in this.objects) {
      sortArray.push({
        name,
        count: this.objects[name]
      });
    }

    return sortArray.sort((a: ObjectTuple, b: ObjectTuple) => b.count - a.count);
  }

  private renderObject(object: ObjectTuple) {
    Html.create(
      'div',
      {
        className: 'object-count',
        textContent: `${object.name} - ${object.count}`
      },
      this.container
    );
  }
}