class LightBox {
  private modalBlocker!: HTMLDivElement;
  private lightBox!: HTMLDivElement;

  public show(content: Node) {
    this.modalBlocker = document.createElement('div');
    this.modalBlocker.id = 'lightbox-modal-blocker';
    document.body.appendChild(this.modalBlocker);
    this.modalBlocker.addEventListener('click', (event: MouseEvent) => event.target === this.modalBlocker && this.hide());

    this.lightBox = document.createElement('div');
    this.lightBox.id = 'lightbox-container';
    this.lightBox.appendChild(content);
    this.modalBlocker.appendChild(this.lightBox);
    document.addEventListener('keydown', this.handleKeys, true);
  }

  public hide = () => {
    document.body.removeChild(this.modalBlocker);
    document.removeEventListener('keydown', this.handleKeys, true);
  }

  private handleKeys = (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
      this.hide();
    }
  }
}