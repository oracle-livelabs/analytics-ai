interface BoundingBox {
  top: number;
  left: number;
  width: number;
  height: number;
}

interface AnalyzedObject {
  text: string;
  coordinates: BoundingBox;
}

interface AnalyzedImage {
  objects: AnalyzedObject[];
  textLines: AnalyzedObject[];
  classifications: AnalyzedObject[];
}

interface ImageInfo {
  analyzedImage: AnalyzedImage;
  imageDataBase64: string;
}

interface ObjectCoordinates {
  [index: string]: BoundingBox[];
}
