/// <reference path="../../../scripts/websocket-client.ts" />

class ImageAnalysisDemo {
  private maxReconnectAttempts = 3;
  private image!: SelfOptimizingImage;
  private imageContainer: HTMLDivElement = Html.get('#image-container')!;
  private contentTemplate!: HTMLDivElement;
  private objectCounter: Counter = new Counter(Html.get('#object-counts')!);
  private textCounter: Counter = new Counter(Html.get('#text-counts')!);
  private lightBox = new LightBox();
  private socket: WebSocketClient = new WebSocketClient({
    address: 'localhost',
    port: 9000
  });

  public async start() {
    try {
      await this.connect();
    } catch (e) {
      console.log('Cannot connect to server', e);
    }
  }

  private async connect() {
    await this.socket.connect();
    this.setupSocket();
    console.log('Connected...');
  }

  private setupSocket() {
    this.socket.addEventListener('message', this.handleMessage);
    this.socket.addEventListener('close', this.reconnect);
    this.socket.addEventListener('error', this.reconnect);
  }

  private handleMessage = (message: MessageEvent<string>) => {
    if (!message.data) {
      return;
    }

    const receivedImages: ImageInfo[] = JSON.parse(message.data);
    this.handleReceivedImages(receivedImages);
  }

  private handleReceivedImages(receivedImages: ImageInfo[]) {
    receivedImages.forEach(this.handleReceivedImage);
  }

  private handleReceivedImage = (receivedImage: ImageInfo) => {
    const htmlImage: HTMLImageElement = Html.create(
      'img', {
        src: receivedImage.imageDataBase64
      },
      this.imageContainer
    );

    this.setupImageUi(htmlImage, receivedImage);
  }

  private setupImageUi(htmlImage: HTMLElement, imageInfo: ImageInfo) {
    this.objectCounter.update(imageInfo.analyzedImage.objects);
    this.textCounter.update(ImageAnalysisDemo.filterTextLine(imageInfo.analyzedImage.textLines));
    htmlImage.addEventListener('click', () => this.showImageDetails(imageInfo));
  }

  private showImageDetails(imageInfo: ImageInfo) {
    this.setupLightBoxContent(imageInfo);
    this.lightBox.show(this.contentTemplate);
  }

  private setupLightBoxContent(imageInfo: ImageInfo) {
    this.contentTemplate = <HTMLDivElement>Html.get('#lightbox-template')?.firstElementChild?.cloneNode(true)!;
    this.getTemplateElement('lightbox-close-button').addEventListener('click', this.lightBox.hide);

    if (this.image !== undefined) {
      this.image.destroy();
    }

    this.image = new SelfOptimizingImage(
      this.getTemplateElement('lightbox-image-wrapper'),
      this.contentTemplate,
      imageInfo.imageDataBase64
    );

    this.fillAllItems(imageInfo.analyzedImage);
  }

  private getTemplateElement<T extends Element>(className: string): T {
    return <T>this.contentTemplate.getElementsByClassName(className)[0];
  }

  private fillAllItems(analyzedImage: AnalyzedImage) {
    this.fillItems('lightbox-objects', analyzedImage.objects, true);
    this.fillItems('lightbox-text', analyzedImage.textLines, false);
    this.fillItems('lightbox-classifications', analyzedImage.classifications, false);
  }

  private fillItems(
    parentElementSelector: string,
    items: AnalyzedObject[],
    sortAndCoalesce: boolean
  ) {
    const parentElement: HTMLDivElement = this.getTemplateElement(parentElementSelector);

    if (!items || items.length === 0) {
      parentElement.style.display = 'none';
      return;
    }

    this.appendItems(parentElement, items, sortAndCoalesce);
  }

  private appendItems(
    parentElement: HTMLElement,
    items: AnalyzedObject[],
    sortAndCoalesce: boolean
  ) {
    if (sortAndCoalesce) {
      this.appendCoalescedItems(parentElement, items);
    } else {
      this.appendItemsOriginalOrder(parentElement, items);
    }
  }

  private appendCoalescedItems(parentElement: HTMLElement, items: AnalyzedObject[]) {
    const itemMap: ObjectCoordinates = ImageAnalysisDemo.coalesceItems(items);
    const itemTexts: string[] = Object.keys(itemMap);

    itemTexts.forEach((itemText: string) => {
      this.createItemElement(parentElement, itemText, itemMap[itemText]);
    });
  }

  private appendItemsOriginalOrder(parentElement: HTMLElement, items: AnalyzedObject[]) {
    items.forEach((item: AnalyzedObject) => {
      this.createItemElement(parentElement, item.text, [item.coordinates]);
    });
  }

  private static coalesceItems(items: AnalyzedObject[]): ObjectCoordinates {
    const itemMap: ObjectCoordinates = {};

    items.forEach((item: AnalyzedObject) => {
      if (itemMap[item.text] === undefined) {
        itemMap[item.text] = [];
      }

      itemMap[item.text].push(item.coordinates);
    });

    return itemMap;
  }

  private createItemElement(
    parentElement: HTMLElement,
    textContent: string,
    boundingBoxes: BoundingBox[]
  ) {
    const itemElement: HTMLDivElement = Html.create('div', { textContent }, parentElement);
    this.setupBoundingBoxesForItem(itemElement, boundingBoxes);
  }

  private setupBoundingBoxesForItem(itemElement: HTMLElement, boundingBoxes: BoundingBox[]) {
    if (boundingBoxes) {
      itemElement.addEventListener('click', () => this.showBoundingBoxes(boundingBoxes));
      itemElement.addEventListener('mouseover', () => this.showBoundingBoxes(boundingBoxes));
      itemElement.addEventListener('mouseout', this.hideBoundingBoxes);
    }
  }

  private showBoundingBoxes(boundingBoxes: BoundingBox[]) {
    this.hideBoundingBoxes();
    const imageWrapper: HTMLDivElement = this.getTemplateElement('lightbox-image-wrapper');

    boundingBoxes.forEach((boundingBox: BoundingBox) => {
      if (boundingBox) {
        const boundingBoxElement: HTMLDivElement = ImageAnalysisDemo.createBoundingBoxElement(boundingBox);
        imageWrapper.appendChild(boundingBoxElement);
      }
    });
  }

  private static createBoundingBoxElement(boundingBox: BoundingBox): HTMLDivElement {
    return Html.create(
      'div',
      {
        className: 'bounding-box',
        style: {
          top: `${boundingBox.top}%`,
          left: `${boundingBox.left}%`,
          width: `${boundingBox.width}%`,
          height: `${boundingBox.height}%`
        }
      }
    );
  }

  private hideBoundingBoxes = () => {
    const imageWrapper: HTMLDivElement = this.getTemplateElement('lightbox-image-wrapper');
    Html.remove('.bounding-box', imageWrapper)
  }

  private static filterTextLine(textLines: AnalyzedObject[]): AnalyzedObject[] {
    return textLines.filter((textLine: AnalyzedObject) => /^[a-z ]{2,}$/i.test(textLine.text));
  }

  private reconnect = async () => {
    try {
      console.log('Disconnected, attempting reconnection');
      this.assertReconnectAttempt();
      await this.start();
    } catch (e) {
      console.log(`Could not reconnect to server`);
    }
  }

  private assertReconnectAttempt() {
    if (this.maxReconnectAttempts-- <= 0) {
      throw new Error('Last reconnection attempt exhausted');
    }
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const imageAnalysisDemo = new ImageAnalysisDemo();
  await imageAnalysisDemo.start();
});