"use strict";
class LightBox {
    modalBlocker;
    lightBox;
    show(content) {
        this.modalBlocker = document.createElement('div');
        this.modalBlocker.id = 'lightbox-modal-blocker';
        document.body.appendChild(this.modalBlocker);
        this.modalBlocker.addEventListener('click', (event) => event.target === this.modalBlocker && this.hide());
        this.lightBox = document.createElement('div');
        this.lightBox.id = 'lightbox-container';
        this.lightBox.appendChild(content);
        this.modalBlocker.appendChild(this.lightBox);
        document.addEventListener('keydown', this.handleKeys, true);
    }
    hide = () => {
        document.body.removeChild(this.modalBlocker);
        document.removeEventListener('keydown', this.handleKeys, true);
    };
    handleKeys = (event) => {
        if (event.key === 'Escape') {
            this.hide();
        }
    };
}
