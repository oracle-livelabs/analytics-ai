"use strict";
class Counter {
    container;
    objects = {};
    constructor(container) {
        this.container = container;
    }
    update(objects) {
        if (!objects) {
            return;
        }
        for (const object of objects) {
            this.updateObject(object);
        }
        this.render();
    }
    updateObject = (object) => {
        if (!this.objects[object.text]) {
            this.objects[object.text] = 0;
        }
        this.objects[object.text]++;
    };
    render() {
        Html.clear(this.container);
        const sortedObjects = this.getObjectsSortedByCount();
        for (const object of sortedObjects) {
            if (object.count < 2) {
                continue;
            }
            this.renderObject(object);
        }
    }
    getObjectsSortedByCount() {
        const sortArray = [];
        for (const name in this.objects) {
            sortArray.push({
                name,
                count: this.objects[name]
            });
        }
        return sortArray.sort((a, b) => b.count - a.count);
    }
    renderObject(object) {
        Html.create('div', {
            className: 'object-count',
            textContent: `${object.name} - ${object.count}`
        }, this.container);
    }
}
