import * as fs from 'fs';
import * as crypto from 'crypto';

import Files, { FileInfo } from '../utils/files';

const photosDirPath = './photos';
const imageHashes: { [key: string]: boolean } = {};

class FileHash {
  private static readonly HashType = 'md5';

  private fileReadStream!: fs.ReadStream;
  private hash!: crypto.Hash;

  constructor(private fileFullPath: string) {
  }

  public async get(): Promise<string> {
    return new Promise((onSuccess, onFailure) => {
      this.setup(onSuccess, onFailure);
    });
  }

  public setup(
    onSuccess: (hash: string) => void,
    onFailure: (error: Error) => void
  ) {
    this.setupHash();
    this.setupReadStream(onSuccess, onFailure);
  }

  private setupReadStream(
    onSuccess: (hash: string) => void,
    onFailure: (error: Error) => void
  ) {
    try {
      this.fileReadStream = fs.createReadStream(this.fileFullPath);
      this.setupStreamEvents(onSuccess, onFailure);
    } catch (e) {
      onFailure(<Error>e);
    }
  }

  private setupStreamEvents(
    onSuccess: (hash: string) => void,
    onFailure: (error: Error) => void
  ) {
    this.fileReadStream.on('error', error => onFailure(error));
    this.fileReadStream.on('data', dataChunk => this.hash.update(dataChunk));
    this.fileReadStream.on('end', () => onSuccess(this.hash.digest('hex')));
  }

  private setupHash() {
    this.hash = crypto.createHash(FileHash.HashType);
  }
}

async function deDupImages(): Promise<void>  {
  await Files.processFiles(photosDirPath, handleImage);
}

async function handleImage(imageFileInfo: FileInfo): Promise<void> {
  const imageFileFullPath = imageFileInfo.fullPath;

  try {
    const fileHash = await getImageFileHash(imageFileFullPath);

    if (fileAlreadyExists(fileHash)) {
      console.log(`File already exists! deleting ${imageFileFullPath}`);
      await deleteImageFile(imageFileFullPath);
    } else {
      addFileHashToDictionary(fileHash);
    }
  } catch (e) {
    console.log('Failure to handle file!', e, imageFileFullPath);
  }
}

async function getImageFileHash(imageFileFullPath: string): Promise<string> {
  const fileHash = new FileHash(imageFileFullPath);

  try {
    return await fileHash.get();
  } catch (e) {
    throw e;
  }
}

function fileAlreadyExists(fileHash: string): boolean {
  return (imageHashes[fileHash] === true);
}

function addFileHashToDictionary(fileHash: string) {
  imageHashes[fileHash] = true;
}

async function deleteImageFile(fileFullPath: string): Promise<void> {
  await fs.promises.unlink(fileFullPath);
}

(async function main() {
  await deDupImages();
})();
