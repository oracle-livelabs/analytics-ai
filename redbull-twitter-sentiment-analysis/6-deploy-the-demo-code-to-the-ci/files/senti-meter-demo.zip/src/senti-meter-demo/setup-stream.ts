import 'dotenv/config';

import { Client } from 'twitter-api-sdk';
import { getRules, TwitterResponse } from 'twitter-api-sdk/dist/types';
    
(async function main() {
  const twitterApiClient = new Client(process.env.TWITTER_BEARER_TOKEN!);
  const rules: TwitterResponse<getRules> = await twitterApiClient.tweets.getRules();
  const numRules = rules.data?.length;

  console.log(`Found ${numRules || 0} filter rules`);

  if (!numRules) {
    await createFilterRule(twitterApiClient);
  } else if (numRules > 1) {
    await clearAndRecreate(twitterApiClient, rules);
  } else {
    const ruleValue = formatFilterRuleValue(rules.data[0].value);

    if (getFilterRuleValue() !== ruleValue) {
      await clearAndRecreate(twitterApiClient, rules);
    } else {
      console.log(`The filter rule is already setup`);
    }
  }

  console.log(`Done.`);
})();

function getFilterRuleValue() {
  return formatFilterRuleValue(process.env.FILTERED_STREAM_FILTER_VALUE!);
}

function getFilterRuleTag() {
  return formatFilterRuleValue(process.env.FILTERED_STREAM_FILTER_TAG!);
}

function formatFilterRuleValue(value: string) {
  return value.trim().toLowerCase();
}

async function createFilterRule(twitterApiClient: Client) {
  console.log(`Creating filter rule`);
  const result = await twitterApiClient.tweets.addOrDeleteRules({
    add: [{
      tag: getFilterRuleTag(),
      value: getFilterRuleValue()
    }]
  });

  if (result.errors && result.errors.length > 0) {
    console.log('Error creating rule:', JSON.stringify(result.errors));
  }
}

async function clearAllRules(twitterApiClient: Client, rules: TwitterResponse<getRules>) {
  console.log(`Clearing all old filter rules`);
  await twitterApiClient.tweets.addOrDeleteRules({
    delete: {
      ids: rules.data.map(rules => rules.id!)
    }
  });
}

async function clearAndRecreate(twitterApiClient: Client, rules: TwitterResponse<getRules>) {
  await clearAllRules(twitterApiClient, rules);
  await createFilterRule(twitterApiClient);
}