import 'dotenv/config';

import { Client } from 'twitter-api-sdk';
import { searchStream, TwitterResponse } from 'twitter-api-sdk/dist/types';

import { ITweetQueue, ITweetQueueOptions, TweetQueueFactory } from './tweet-queue/tweet-queue';

async function delay(delayMs: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, delayMs));
}

(async function main() {
  const tweetQueueOptions: ITweetQueueOptions = {
    rootDir: './tweets-queue',
    clearQueue: true
  };

  const MaxRetries = 5;

  const tweetQueue: ITweetQueue = await TweetQueueFactory.create(tweetQueueOptions);
  const client = new Client(process.env.TWITTER_BEARER_TOKEN!);
  let retries = 0;

  while (retries < MaxRetries) {
    const stream: AsyncGenerator<TwitterResponse<searchStream>> = client.tweets.searchStream();
    let tweetCount = 0;

    try {
      console.log('Retrieving tweets...');

      for await (const tweet of stream) {
        retries = 0;
        await tweetQueue.enqueue(tweet.data!);
        console.log(`Queued tweet #${++tweetCount}`);
      }
    }
    catch (e) {
      console.log('Error getting tweets', e);
    }
    finally {
      console.log('Retrying connection...');
      retries++;
      await delay(10000);
    }
  }

  console.log('Consumer exiting');
})();