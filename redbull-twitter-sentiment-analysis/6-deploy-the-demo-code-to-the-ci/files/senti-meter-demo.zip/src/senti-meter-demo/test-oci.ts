import 'dotenv/config';

import { LanguageAiApi } from '../oci-apis/language-ai';

(async function main() {
  try {
    console.log('Testing the OCI Language API...');
    const languageAi = new LanguageAiApi();
    await languageAi.analyzeText(['just some text']);
    console.log('OCI API authentication is setup correctly.');
  } catch (e) {
    console.log('An error has occurred:');
    console.log(e);
  }
})();