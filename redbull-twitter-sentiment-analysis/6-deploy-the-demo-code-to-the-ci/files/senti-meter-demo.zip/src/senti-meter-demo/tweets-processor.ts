import 'dotenv/config';

import { LanguageAnalysisBatchBuffer, LanguageAnalysisBufferAppendCode } from '../language-analysis-buffer/language-analysis-buffer';
import { LanguageAiApi } from '../oci-apis/language-ai';
import { ITweet, ITweetQueue, ITweetQueueOptions, TweetQueueFactory } from './tweet-queue/tweet-queue';
import { WebSocketServer } from '../utils/websocket-server';

const tweetPollDelayMs = 1000;

let webSocketsServer: WebSocketServer;
let languageAi: LanguageAiApi;
let tweetQueue: ITweetQueue;
let languageAnalysisBatchBuffer: LanguageAnalysisBatchBuffer;
let tweetCount = 0;

async function processTweets() {
  try {
    let tweet: ITweet | null;

    while (tweet = await tweetQueue.dequeue()) {
      console.log(`Dequeued: ${++tweetCount}`);
      await appendTweetToBuffer(tweet);
    }
    await flushTweetsBuffer();
  } catch (e) {
    console.log('Error occurred:');
    console.log(e);
  }

  setTimeout(processTweets, tweetPollDelayMs);
}

async function appendTweetToBuffer(tweet: ITweet): Promise<void> {
  try {
    languageAnalysisBatchBuffer.append(tweet.text);
  } catch (appendCode) {
    if (appendCode === LanguageAnalysisBufferAppendCode.LimitExceeded) {
      await flushTweetsBuffer();
      languageAnalysisBatchBuffer.append(tweet.text);
    }
  }
}

async function flushTweetsBuffer() {
  const texts: string[] = languageAnalysisBatchBuffer.flushBuffer();

  if (texts && texts.length > 0) {
    await processLanguageBatch(texts);
  }
}

async function processLanguageBatch(texts: string[]) {
  console.log(`Processing a batch of ${texts.length} tweets`);
  const analysisResults: string[] | undefined = await analyzeLanguageBatch(texts);

  if (analysisResults) {
    console.log(`sending ${analysisResults.length} messages`);
    webSocketsServer.send(analysisResults.join(','));
  }
}

async function analyzeLanguageBatch(texts: string[]): Promise<string[] | undefined> {
  try {
    return await languageAi.analyzeText(texts);
  } catch (e) {
    console.log(`Error processing last batch of ${texts.length} records`);
  }
}

async function initialize() {
  const tweetQueueOptions: ITweetQueueOptions = {
    rootDir: './tweets-queue'
  };

  tweetQueue = await TweetQueueFactory.create(tweetQueueOptions);
  languageAnalysisBatchBuffer = new LanguageAnalysisBatchBuffer();
  languageAi = new LanguageAiApi();
  webSocketsServer = new WebSocketServer({
    port: parseInt(process.env.PROCESSOR_SERVER_PORT!),
    address: process.env.LISTEN_ADDRESS!,
    certificate: {
      certificateFilePath: process.env.CERT_FILE!,
      keyFilePath: process.env.KEY_FILE!,
    }
  });

  await webSocketsServer.start();
}

(async function main() {
  await initialize();
  await processTweets();
})();