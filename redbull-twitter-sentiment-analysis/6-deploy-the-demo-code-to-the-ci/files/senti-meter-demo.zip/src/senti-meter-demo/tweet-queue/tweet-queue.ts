import * as fs from 'fs';
import path from 'path';
import { randomUUID } from 'crypto';

import chokidar from 'chokidar';

import Files from '../../utils/files';

export interface ITweet {
  id: string;
  text: string;
}

export type OnNewMessageCallback = () => Promise<void>;

export interface ITweetQueue {
  enqueue(tweet: ITweet): Promise<void>;
  dequeue(): Promise<ITweet | null>;
}

export interface ITweetQueueOptions {
  rootDir: string;
  clearQueue?: boolean;
}

class TweetQueue implements ITweetQueue {
  private static readonly NewMessagesDir = 'new';
  private static readonly FrozenDirIndicatorFileName = 'frozen';
  private static readonly MessageFileExtension = '.json';
  private static readonly MaxFilesPerNewMessagesDir = 100;

  private tweetQueue: string[] = [];
  private rootPath: string;
  private newMessagesRootPath: string;
  private currentNewMessagesPath: string | undefined;
  private newMessageDirFileCount = 0;

  constructor(private options: ITweetQueueOptions) {
    this.rootPath = options.rootDir;
    this.newMessagesRootPath = `${this.rootPath}/${TweetQueue.NewMessagesDir}`;
  }

  public async initialize() {
    if (this.options.clearQueue) {
      await this.clearQueue();
    }

    await this.createDirStructure();
    this.listenToNewMessages();
  }

  public async enqueue(tweet: ITweet): Promise<void> {
    if (this.currentNewMessagesPath === undefined) {
      await this.createNewNewMessagesDir();
    }

    await this.writeMessageFile(tweet);
    await this.handleFileEnqueued();
  }

  public async dequeue(): Promise<ITweet | null> {
    if (this.tweetQueue.length === 0) {
      return null;
    }

    const nextTweetFile: string = this.tweetQueue.pop()!;
    return await TweetQueue.consumeMessageFile(nextTweetFile);
  }

  private listenToNewMessages() {
    const watcher: chokidar.FSWatcher = chokidar.watch(this.newMessagesRootPath);
    watcher.on('add', this.handleNewMessage);
  }

  private async clearQueue() {
    await fs.promises.rm(this.newMessagesRootPath, {
      recursive: true,
      force: true
    });
  }

  private async createDirStructure() {
    await Files.mkDirIfNotExists(this.rootPath);
    await Files.mkDirIfNotExists(this.newMessagesRootPath);
  }

  private static async consumeMessageFile(messageFileFullPath: string): Promise<ITweet> {
    const tweet: ITweet = await TweetQueue.readTweetFile(messageFileFullPath);
    await TweetQueue.removeCompletedMessage(messageFileFullPath);
    return tweet;
  }

  private handleNewMessage = async (fullFilePath: string): Promise<void> => {
    if (fullFilePath.endsWith(TweetQueue.MessageFileExtension)) {
      this.tweetQueue.push(fullFilePath);
    }
  };

  private async createNewNewMessagesDir() {
    const newPath = `${this.newMessagesRootPath}/${randomUUID()}`;
    await fs.promises.mkdir(newPath);
    this.currentNewMessagesPath = newPath;
  }

  private async writeMessageFile(tweet: ITweet): Promise<void> {
    const filePath = `${this.currentNewMessagesPath}/${tweet.id}${TweetQueue.MessageFileExtension}`;
    await fs.promises.writeFile(filePath, JSON.stringify(tweet));
  }

  private async handleFileEnqueued() {
    this.newMessageDirFileCount++;

    if (this.newMessageDirFileCount > TweetQueue.MaxFilesPerNewMessagesDir) {
      await this.freezeCurrentMessageFolder();
      this.newMessageDirFileCount = 0;
    }
  }

  private async freezeCurrentMessageFolder() {
    const filePath = `${this.currentNewMessagesPath}/${TweetQueue.FrozenDirIndicatorFileName}`;
    fs.closeSync(fs.openSync(filePath, 'w'));
    await this.createNewNewMessagesDir();
  }

  private static async readTweetFile(fullFilePath: string): Promise<ITweet> {
    const tweetData: Buffer = await fs.promises.readFile(fullFilePath);
    return JSON.parse(tweetData.toString('utf-8'));
  }

  private static async removeCompletedMessage(fileFullPath: string) {
    await fs.promises.unlink(fileFullPath);
    await TweetQueue.checkRemoveEmptyMessagesDir(fileFullPath);
  }

  private static async checkRemoveEmptyMessagesDir(filePath: string) {
    const dirFullPath: string = path.dirname(filePath);
    const files: string[] = await Files.getFilesInDir(dirFullPath);

    if (files.length === 1 && files[0] === TweetQueue.FrozenDirIndicatorFileName) {
      TweetQueue.removeFrozenMessagesDir(dirFullPath);
    }
  }

  private static async removeFrozenMessagesDir(dirPath: string) {
    await fs.promises.rm(dirPath, { recursive: true, force: true });
  }
}

export class TweetQueueFactory {
  public static async create(options: ITweetQueueOptions): Promise<ITweetQueue> {
    const iTweeterQueue = new TweetQueue(options);
    await iTweeterQueue.initialize();
    return iTweeterQueue;
  }
}