import 'dotenv/config';
import { randomUUID } from 'crypto';

import { ITweet, ITweetQueue, ITweetQueueOptions, TweetQueueFactory } from './tweet-queue/tweet-queue';

interface TweetGenerationPercentage {
  positivePercentage: number;
  negativePercentage: number;
}

enum TweetGenerationTypes {
  Negative,
  TrendingNegative,
  Balanced,
  TrendingPositive,
  Positive
};

type TweetGenerationConfigurations = {
  [index in TweetGenerationTypes]: TweetGenerationPercentage;
}

class TweetsGenerator {
  private static WordsPerTweet = 10;
  private static PositiveWords: string[] = [
    'great', 'awesome', 'amazing', 'spectacular', 'best', 'happy', 'extremely satisfied',
    'helpful', 'useful', 'accommodating', 'valuable', 'inspiring', 'good', 'smart',
    'beautiful'
  ];

  private static NegativeWords: string[] = [
    'bad', 'disappointing', 'neglected', 'sad', 'unhappy', 'inpatient', 'ugly',
    'annoying', 'infuriating', 'painful', 'greedy', 'grumpy'
  ];

  public static generateTweets(amount: number, percentages: TweetGenerationPercentage): ITweet[] {
    const generatedTweets: ITweet[] = [];

    for (let i = 0; i < amount; i++) {
      generatedTweets.push(this.generateTweet(percentages));
    }

    return generatedTweets;
  }

  private static generateTweet(percentages: TweetGenerationPercentage): ITweet {
    return {
      id: randomUUID(),
      text: this.generateTweetText(percentages)
    };
  }

  private static generateTweetText(percentages: TweetGenerationPercentage): string {
    const numPositiveWords = this.numWordsToGenerate(percentages.positivePercentage);
    const numNegativeWords = this.numWordsToGenerate(percentages.negativePercentage);
    const positiveSentence: string[] = this.getRandomWords(numPositiveWords, this.PositiveWords);
    const negativeSentence: string[] = this.getRandomWords(numNegativeWords, this.NegativeWords);

    return this.weaveWordsToSentence(positiveSentence, negativeSentence);
  }

  private static numWordsToGenerate(percentage: number): number {
    return Math.round(this.WordsPerTweet * (percentage / 100));
  }

  private static getRandomWords(numWords: number, source: string[]): string[] {
    let sentence: string[] = [];

    for (let i = 0; i < numWords; i++) {
      sentence.push(source[this.randomNumberUpTo(source.length - 1)]);
    }

    return sentence;
  }

  private static randomNumberUpTo(to: number): number {
    return Math.round(Math.random() * to);
  }

  private static weaveWordsToSentence(words1: string[], words2: string[]): string {
    const words: string[] = [];

    while (words1.length && words2.length) {
      const random = this.randomNumberUpTo(1);

      if (random === 1) {
        words.push(words2.pop()!);
      } else {
        words.push(words1.pop()!);
      }
    }

    words.push(...words1);
    words.push(...words2);

    return words.join(' ');
  }
}

class TweetsRandomGenerator {
  private static TweetsPerPollInterval = parseInt(process.env.TWEETS_PER_SECOND!);
  private static PollIntervalMs = 1000;
  private static TweetGenerationConfigurations: TweetGenerationConfigurations = {
    [TweetGenerationTypes.Negative]: {
      positivePercentage: 10,
      negativePercentage: 90
    },
    [TweetGenerationTypes.TrendingNegative]: {
      positivePercentage: 40,
      negativePercentage: 60
    },
    [TweetGenerationTypes.Balanced]: {
      positivePercentage: 50,
      negativePercentage: 50
    },
    [TweetGenerationTypes.TrendingPositive]: {
      positivePercentage: 60,
      negativePercentage: 40
    },
    [TweetGenerationTypes.Positive]: {
      positivePercentage: 90,
      negativePercentage: 10
    }
  };

  private tweetQueue!: ITweetQueue;

  constructor(private generationConfiguration: TweetGenerationTypes) {}

  public async start() {
    await this.initializeTweetsQueue();
    this.generate();
  }

  private async initializeTweetsQueue() {
    const tweetQueueOptions: ITweetQueueOptions = {
      rootDir: './tweets-queue',
      clearQueue: true
    };

    this.tweetQueue = await TweetQueueFactory.create(tweetQueueOptions);
  }

  private generate = async () => {
    const generationPercentage: TweetGenerationPercentage = TweetsRandomGenerator.TweetGenerationConfigurations[this.generationConfiguration];
    const tweets: ITweet[] = TweetsGenerator.generateTweets(TweetsRandomGenerator.TweetsPerPollInterval, generationPercentage);

    for (const tweet of tweets) {
      try {
        console.log(`Enqueuing tweet - ${tweet.id}`);
        await this.tweetQueue.enqueue(tweet);
      } catch (e) {
        console.log('Error:', e);
      }
    }

    setTimeout(this.generate, TweetsRandomGenerator.PollIntervalMs);
  }
}

(async function main() {
  const tweetsRandomGenerator = new TweetsRandomGenerator(parseInt(process.env.TWEET_GENERATION_TYPE!));
  await tweetsRandomGenerator.start();
})();