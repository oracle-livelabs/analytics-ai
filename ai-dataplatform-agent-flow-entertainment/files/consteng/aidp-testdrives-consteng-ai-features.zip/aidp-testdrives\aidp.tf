# -----------------------------------------------------------------------------
# HOL Provisioning — AI Data Platform Workbench
#
# Creates the AIDP Workbench instance after the AI Lakehouse ADB has been
# provisioned and populated with construction engineering data (database.tf).
#
# The AIDP Workbench will use the existing ALH Autonomous Database in the
# same compartment.
# -----------------------------------------------------------------------------

resource "oci_ai_data_platform_ai_data_platform" "workshop" {
  compartment_id = local.effective_compartment_ocid
  display_name   = "hol-workshop-${local.res_suffix}-${random_string.deploy_id.result}"

  freeform_tags = {
    project = "hol"
    managed = "terraform"
    res_id  = local.res_suffix
  }

  timeouts {
    create = "90m"
    delete = "60m"
  }

  # Wait for the ALH ADB to be fully provisioned and populated before
  # creating the AIDP instance so it can discover the existing database.
  depends_on = [
    null_resource.load_data,
  ]
}

# -----------------------------------------------------------------------------
# Assign LiveLabs User to AI_DATA_PLATFORM_ADMIN Role
#
# AIDP has its own RBAC system separate from OCI IAM. Even with OCI IAM
# policies granting access, the user MUST also be assigned an AIDP role.
# Without this, the user gets RBAC 404 errors in the Workbench.
# -----------------------------------------------------------------------------
resource "null_resource" "assign_admin_role" {
  count = var.ociUserOcid != "" ? 1 : 0

  triggers = {
    instance_id = oci_ai_data_platform_ai_data_platform.workshop.id
    user_ocid   = var.ociUserOcid
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    environment = {
      AIDP_INSTANCE_ID = oci_ai_data_platform_ai_data_platform.workshop.id
      REGION           = local.effective_region
      USER_OCID        = var.ociUserOcid
    }
    command = <<-SCRIPT
      set +e

      echo "============================================================"
      echo "  Assigning AIDP ADMIN Role"
      echo "============================================================"
      echo "  User OCID: $USER_OCID"

      BASE_URL="https://aidp.$REGION.oci.oraclecloud.com/20240831/dataLakes/$AIDP_INSTANCE_ID"

      # ------------------------------------------------------------------
      # Step 1: Assign user to AI_DATA_PLATFORM_ADMIN role
      # ------------------------------------------------------------------
      echo ""
      echo "[Step 1/2] Assigning AI_DATA_PLATFORM_ADMIN role..."

      ROLE_RESPONSE=$(oci raw-request \
        --http-method POST \
        --target-uri "$BASE_URL/roles/AI_DATA_PLATFORM_ADMIN/actions/addMember" \
        --request-body "{\"assignees\": [{\"target\": \"$USER_OCID\", \"type\": \"USER\"}]}" \
        2>&1) || true

      if echo "$ROLE_RESPONSE" | grep -q '"status": 2'; then
        echo "  Role assigned successfully"
      elif echo "$ROLE_RESPONSE" | grep -q '409'; then
        echo "  User already has ADMIN role — skipping"
      else
        echo "  WARNING: Unexpected response:"
        echo "  $ROLE_RESPONSE" | head -10
        echo "  Continuing to RBAC verification..."
      fi

      # ------------------------------------------------------------------
      # Step 2: Wait for RBAC propagation
      #
      # AIDP RBAC grants are not instant. Poll list_workspaces (an
      # RBAC-gated call) until it succeeds, confirming the role is active.
      # ------------------------------------------------------------------
      echo ""
      echo "[Step 2/2] Verifying RBAC propagation..."

      MAX_ATTEMPTS=24
      ATTEMPT=0
      while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
        RBAC_CHECK=$(oci raw-request \
          --http-method GET \
          --target-uri "$BASE_URL/workspaces" \
          2>&1) || true

        if echo "$RBAC_CHECK" | grep -q '"status": 2'; then
          echo "  ADMIN role confirmed active"
          break
        fi

        if echo "$RBAC_CHECK" | grep -qi 'RBAC'; then
          ATTEMPT=$((ATTEMPT + 1))
          if [ $((ATTEMPT % 6)) -eq 0 ]; then
            echo "  RBAC not yet active, waiting... ($((ATTEMPT * 5))s elapsed)"
          fi
          sleep 5
        else
          # Non-RBAC response — role is effective, proceed
          echo "  ADMIN role verification complete"
          break
        fi
      done

      if [ $ATTEMPT -ge $MAX_ATTEMPTS ]; then
        echo "  WARNING: RBAC propagation timed out after 2 min"
        echo "  The user may need to wait before accessing the Workbench"
      fi

      echo ""
      echo "============================================================"
      echo "  AIDP ADMIN Role Assignment Complete"
      echo "============================================================"
    SCRIPT
  }

  depends_on = [
    oci_ai_data_platform_ai_data_platform.workshop,
  ]
}


# -----------------------------------------------------------------------------
# Experimental: Activate AIDP AI Features
#
# The Terraform provider does not yet expose this operation as a native
# resource. This local-exec provisioner calls the AIDP enableAiFeature API after
# the Workbench has been created, targeting the construction engineering ALH ADB.
#
# The route was validated in OCI Resource Manager on 2026-07-06:
#   POST /20240831/aiDataPlatforms/<aidp_instance_id>/actions/enableAiFeature
# with body:
#   {"vectorDbId":"<adb_ocid>","vectorDbAdminCred":"<admin_password>"}
# returned 202 Accepted with an opc-work-request-id.
# -----------------------------------------------------------------------------
resource "null_resource" "activate_ai_features" {
  triggers = {
    aidp_instance_id   = oci_ai_data_platform_ai_data_platform.workshop.id
    target_database_id = oci_database_autonomous_database.construction_engineering.id
    region             = local.effective_region
    script_version     = "enable_ai_feature_aidp_platform_v2"
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    environment = {
      AIDP_INSTANCE_ID   = oci_ai_data_platform_ai_data_platform.workshop.id
      TARGET_DATABASE_ID = oci_database_autonomous_database.construction_engineering.id
      REGION             = local.effective_region
      COMPARTMENT_OCID   = local.effective_compartment_ocid
      ADB_ADMIN_PASSWORD = nonsensitive(random_password.adb_admin.result)
    }
    command = <<-SCRIPT
      set +e

      echo "============================================================"
      echo "  Activating AIDP AI Features"
      echo "============================================================"
      echo "  AIDP Instance:   $AIDP_INSTANCE_ID"
      echo "  Target Database: $TARGET_DATABASE_ID"
      echo "  Compartment:     $COMPARTMENT_OCID"
      echo "  Region:          $REGION"
      echo "  Body shape:      {\"vectorDbId\":\"<adb_ocid>\",\"vectorDbAdminCred\":\"***\"}"

      AIDP_SERVICE="https://aidp.$REGION.oci.oraclecloud.com"
      PLATFORM_BASE="$AIDP_SERVICE/20240831/aiDataPlatforms/$AIDP_INSTANCE_ID"
      DATALAKE_BASE="$AIDP_SERVICE/20240831/dataLakes/$AIDP_INSTANCE_ID"
      TARGET_URI="$PLATFORM_BASE/actions/enableAiFeature"

      is_success() {
        echo "$1" | grep -Eiq '"status"[[:space:]]*:[[:space:]]*"?(200|201|202|204)|200 OK|201 Created|202 Accepted|204 No Content'
      }

      is_already_enabled() {
        echo "$1" | grep -Eiq 'already|enabled|409|conflict'
      }

      echo ""
      echo "[Debug] AIDP feature statuses before enablement:"
      BEFORE_RESPONSE=$(oci raw-request \
        --http-method GET \
        --target-uri "$DATALAKE_BASE/featureStatuses" \
        2>&1)
      echo "$BEFORE_RESPONSE"

      REQUEST_BODY=$(python3 -c "import json, os; print(json.dumps({'vectorDbId': os.environ['TARGET_DATABASE_ID'], 'vectorDbAdminCred': os.environ['ADB_ADMIN_PASSWORD']}))")

      echo ""
      echo "Submitting AI feature activation request..."
      echo "  Target URI: $TARGET_URI"
      RESPONSE=$(oci raw-request \
        --http-method POST \
        --target-uri "$TARGET_URI" \
        --request-body "$REQUEST_BODY" \
        2>&1)
      CLI_STATUS=$?
      echo "$RESPONSE"

      if is_already_enabled "$RESPONSE"; then
        echo "AI features appear to already be enabled; continuing."
        ENABLE_STATUS=0
      elif is_success "$RESPONSE"; then
        echo "AI feature activation request submitted successfully."
        ENABLE_STATUS=0
      elif [ $CLI_STATUS -ne 0 ]; then
        echo "ERROR: OCI CLI raw-request failed with exit code $CLI_STATUS"
        ENABLE_STATUS=$CLI_STATUS
      else
        echo "ERROR: AI feature activation request failed."
        ENABLE_STATUS=1
      fi

      WORK_REQUEST_ID=$(RESPONSE_JSON="$RESPONSE" python3 - <<'PY'
import json
import os

raw = os.environ.get("RESPONSE_JSON", "")
work_request_id = ""
try:
    obj = json.loads(raw)
    work_request_id = (obj.get("headers") or {}).get("opc-work-request-id", "")
except Exception:
    work_request_id = ""

print(work_request_id)
PY
)

      if [ -n "$WORK_REQUEST_ID" ]; then
        WORK_REQUEST_URI="$AIDP_SERVICE/20240831/workRequests/$WORK_REQUEST_ID"
        echo ""
        echo "[Debug] Polling work request: $WORK_REQUEST_ID"
        for ATTEMPT in $(seq 1 30); do
          WORK_RESPONSE=$(oci raw-request \
            --http-method GET \
            --target-uri "$WORK_REQUEST_URI" \
            2>&1)
          echo "[Debug] Work request poll $ATTEMPT:"
          echo "$WORK_RESPONSE"

          if echo "$WORK_RESPONSE" | grep -Eiq '404 Not Found|NotAuthorizedOrNotFound'; then
            echo "[Debug] Work request polling endpoint did not resolve; continuing with final feature-status check."
            break
          fi

          if echo "$WORK_RESPONSE" | grep -Eiq '"status"[[:space:]]*:[[:space:]]*"(SUCCEEDED|SUCCESS|COMPLETED)"|"operationStatus"[[:space:]]*:[[:space:]]*"(SUCCEEDED|SUCCESS|COMPLETED)"|"lifecycleState"[[:space:]]*:[[:space:]]*"(SUCCEEDED|SUCCESS|COMPLETED)"'; then
            echo "AI feature activation work request completed successfully."
            ENABLE_STATUS=0
            break
          fi

          if echo "$WORK_RESPONSE" | grep -Eiq '"status"[[:space:]]*:[[:space:]]*"(FAILED|CANCELED|CANCELLED)"|"operationStatus"[[:space:]]*:[[:space:]]*"(FAILED|CANCELED|CANCELLED)"|"lifecycleState"[[:space:]]*:[[:space:]]*"(FAILED|CANCELED|CANCELLED)"'; then
            echo "ERROR: AI feature activation work request failed or was canceled."
            ENABLE_STATUS=1
            break
          fi

          sleep 10
        done
      else
        echo "[Debug] No work request id was returned by the activation call."
      fi

      echo ""
      echo "[Debug] Waiting 20 seconds before checking AIDP feature statuses again..."
      sleep 20

      echo "[Debug] AIDP feature statuses after enablement attempt:"
      AFTER_RESPONSE=$(oci raw-request \
        --http-method GET \
        --target-uri "$DATALAKE_BASE/featureStatuses" \
        2>&1)
      echo "$AFTER_RESPONSE"

      exit "$ENABLE_STATUS"
    SCRIPT
  }

  depends_on = [
    oci_ai_data_platform_ai_data_platform.workshop,
    null_resource.load_data,
  ]
}

# -----------------------------------------------------------------------------
# Outputs
# -----------------------------------------------------------------------------
output "aidp_instance_id" {
  description = "OCID of the AIDP Workbench instance"
  value       = oci_ai_data_platform_ai_data_platform.workshop.id
}

output "aidp_instance_display_name" {
  description = "Display name of the AIDP Workbench instance"
  value       = oci_ai_data_platform_ai_data_platform.workshop.display_name
}

output "aidp_instance_state" {
  description = "Lifecycle state of the AIDP Workbench instance"
  value       = oci_ai_data_platform_ai_data_platform.workshop.state
}
