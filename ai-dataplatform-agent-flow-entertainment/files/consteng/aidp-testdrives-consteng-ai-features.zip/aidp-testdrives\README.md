# AIDP Construction Engineering Hands-on Lab - Provisioning Guide

Automated provisioning for the Oracle AI Data Platform construction engineering supplier evaluation workshop.

This Terraform stack creates:

- An Autonomous AI Lakehouse database named `hol-consteng-<reservation>-<suffix>`
- The `CONSTRUCTION_ENGINEERING` and `CONSTRUCTION_ENGINEERINGAPEX` database schemas
- Construction engineering project, supplier, certification, performance, recommendation, document, decision, vector chunk, duality view, and property graph objects
- An AIDP Workbench instance that depends on database setup completion
- Seed knowledge base documents and agent instructions under `data_dir`

## Database Content

The database scripts are aligned with the construction engineering narrative:

- `00_create_schema.sql` creates and grants the construction engineering schemas.
- `01_create_tables.sql` creates the construction engineering tables.
- `02_load_data.sql` loads sample project and supplier data, then creates the JSON relational duality view and property graph.

## Seed Files

The `data_dir` folder contains:

- `Agent Instructions.txt`
- `Docs/CE_Supplier_Evaluation_Playbook.docx`
- `Docs/CE_Compliance_Certification_Guidelines.docx`
- `Docs/CE_Technical_Addendum_Risk_Triage.docx`

These files support the RAG and agent instruction portions of the workshop.

## Resource Naming

The database display name uses the `hol-consteng-` prefix. The database name uses the compact `holce` prefix to satisfy Autonomous Database naming constraints.

## Operation

Upload this directory as an OCI Resource Manager stack. LiveLabs injects tenancy, compartment, region, reservation, and user variables through `schema.yaml` and `variables.tf`.


## Experimental AI Feature Activation Fork

This package includes `null_resource.activate_ai_features` in `aidp.tf`.
The resource calls the AIDP `enableAiFeature` API with an existing ALH database:

- `vectorDbId`: the construction engineering Autonomous AI Lakehouse database OCID
- `vectorDbAdminCred`: the generated Autonomous Database admin password
- endpoint: `https://aidp.<region>.oci.oraclecloud.com`
- path: `/20240831/aiDataPlatforms/<aidp_instance_id>/actions/enableAiFeature`

This route was validated in OCI Resource Manager on July 6, 2026. The API
returned `202 Accepted` with an `opc-work-request-id`.

The script now:

- checks `/20240831/dataLakes/<aidp_instance_id>/featureStatuses` before and after activation
- submits the activation request to the validated `aiDataPlatforms` action route
- extracts and polls the returned AIDP work request when available
- keeps the generated admin password out of printed request-body logs

This is intended to test whether the manual Lab 00 enablement step can be removed. Keep the standard `aidp-testdrives-consteng.zip` package as the control package until this fork is validated in OCI Resource Manager.
