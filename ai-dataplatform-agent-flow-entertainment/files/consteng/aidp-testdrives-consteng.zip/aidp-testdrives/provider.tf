# -----------------------------------------------------------------------------
# HOL Provisioning — Provider Configuration
#
# LiveLabs / OCI Resource Manager handles authentication automatically.
# No explicit auth block needed — ORM injects credentials at apply time.
# -----------------------------------------------------------------------------

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    oci = {
      source  = "oracle/oci"
      version = ">= 8.5.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.0.0"
    }
  }
}

provider "oci" {
  # When region is null (neither LiveLabs nor ORM injected it), the provider
  # falls back to ORM's environment-level region detection (Instance Principal).
  region = local.effective_region
}
