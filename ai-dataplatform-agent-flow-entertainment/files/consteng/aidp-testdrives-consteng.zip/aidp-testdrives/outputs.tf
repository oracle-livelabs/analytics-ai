# -----------------------------------------------------------------------------
# HOL Provisioning — Outputs
# -----------------------------------------------------------------------------

# --- General ---

output "compartment_ocid" {
  description = "Compartment OCID where all resources are provisioned"
  value       = local.effective_compartment_ocid
}

output "region" {
  description = "OCI region"
  value       = local.effective_region
}

# --- AI Lakehouse Autonomous Database ---

output "adb_id" {
  description = "OCID of the AI Lakehouse Autonomous Database"
  value       = oci_database_autonomous_database.construction_engineering.id
}

output "adb_display_name" {
  description = "Display name of the Autonomous Database"
  value       = oci_database_autonomous_database.construction_engineering.display_name
}

output "adb_db_name" {
  description = "ADB database name (used in TNS aliases, e.g. <db_name>_high)"
  value       = oci_database_autonomous_database.construction_engineering.db_name
}

output "adb_connection_urls" {
  description = "ADB connection URLs"
  value       = oci_database_autonomous_database.construction_engineering.connection_urls
}

output "adb_admin_password" {
  description = "Admin password for the Autonomous Database"
  value       = random_password.adb_admin.result
  sensitive   = true
}

# --- AIDP Workbench (defined in aidp.tf) ---
# aidp_instance_id, aidp_instance_display_name, aidp_instance_state
