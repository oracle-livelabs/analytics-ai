# -----------------------------------------------------------------------------
# HOL Provisioning — Main Configuration
#
# OCI-native resources managed directly by Terraform.
# Autonomous Database resources are in database.tf.
# AIDP Workbench instance and internal resources (workspaces, catalogs,
# knowledge bases, agent flows) are provisioned manually via the workshop labs.
# -----------------------------------------------------------------------------

