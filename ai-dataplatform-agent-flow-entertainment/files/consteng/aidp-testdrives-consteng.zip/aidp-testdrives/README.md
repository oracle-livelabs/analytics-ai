# AIDP Construction Engineering Hands-on Lab - Provisioning Guide

Automated provisioning for the Oracle AI Data Platform construction engineering supplier evaluation workshop.

This Terraform stack creates:

- An Autonomous AI Lakehouse database named `hol-consteng-<reservation>-<suffix>`
- The `CONSTRUCTION_ENGINEERING` and `CONSTRUCTION_ENGINEERINGAPEX` database schemas
- Construction engineering project, supplier, certification, performance, recommendation, document, decision, vector chunk, duality view, and property graph objects
- An AIDP Workbench instance that depends on database setup completion
- Seed knowledge base documents and agent instructions under `data_dir`

## Database Content

The database scripts are aligned with the construction engineering narrative:

- `00_create_schema.sql` creates and grants the construction engineering schemas.
- `01_create_tables.sql` creates the construction engineering tables.
- `02_load_data.sql` loads sample project and supplier data, then creates the JSON relational duality view and property graph.

## Seed Files

The `data_dir` folder contains:

- `Agent Instructions.txt`
- `Docs/CE_Supplier_Evaluation_Playbook.docx`
- `Docs/CE_Compliance_Certification_Guidelines.docx`
- `Docs/CE_Technical_Addendum_Risk_Triage.docx`

These files support the RAG and agent instruction portions of the workshop.

## Resource Naming

The database display name uses the `hol-consteng-` prefix. The database name uses the compact `holce` prefix to satisfy Autonomous Database naming constraints.

## Operation

Upload this directory as an OCI Resource Manager stack. LiveLabs injects tenancy, compartment, region, reservation, and user variables through `schema.yaml` and `variables.tf`.
