# -----------------------------------------------------------------------------
# HOL Provisioning — Input Variables
#
# Variables prefixed with "oci" are injected by OCI Resource Manager / LiveLabs.
# Variables prefixed with "res" are reservation-specific values from LiveLabs.
# All others are HOL-specific configuration.
# -----------------------------------------------------------------------------

# =============================================================================
# ORM Standard Variables (auto-injected by Resource Manager)
# =============================================================================

variable "tenancy_ocid" {
  description = "OCID of the tenancy (auto-injected by ORM)"
  type        = string
  default     = null
}

variable "compartment_ocid" {
  description = "OCID of the compartment (auto-injected by ORM)"
  type        = string
  default     = null
}

variable "region" {
  description = "OCI region identifier (auto-injected by ORM)"
  type        = string
  default     = null
}

# =============================================================================
# LiveLabs-Injected Variables (auto-populated by OCI Resource Manager)
# =============================================================================

variable "ociTenancyOcid" {
  description = "OCID of the OCI tenancy (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "ociUserOcid" {
  description = "OCID of the OCI user (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "ociCompartmentOcid" {
  description = "OCID of the compartment for all HOL resources (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "ociRegionIdentifier" {
  description = "OCI region identifier, e.g. us-ashburn-1 (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "resId" {
  description = "Unique reservation ID for resource naming (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "ociUserPassword" {
  description = "User password (injected by LiveLabs)"
  type        = string
  default     = ""
  sensitive   = true
}

variable "ociVcnOcid" {
  description = "VCN OCID (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "ociPublicSubnetOcid" {
  description = "Public subnet OCID (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "ociPrivateSubnetOcid" {
  description = "Private subnet OCID (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "resUserPublicKey" {
  description = "User's public SSH key (injected by LiveLabs)"
  type        = string
  default     = ""
}

variable "ociGenAiRegion" {
  description = "Region for GenAI services (injected by LiveLabs)"
  type        = string
  default     = ""
}

# =============================================================================
# Random Password — Used to reset the AIDP-managed ADB admin password
# =============================================================================

resource "random_password" "adb_admin" {
  length           = 16
  special          = true
  min_numeric      = 2
  min_lower        = 2
  min_upper        = 2
  min_special      = 1
  override_special = "#_-"
}

locals {
  # ORM injects standard names: tenancy_ocid, compartment_ocid, region.
  # LiveLabs may inject custom names: ociTenancyOcid, ociCompartmentOcid, ociRegionIdentifier.
  # Prefer standard ORM names (always populated by ORM), fall back to custom LiveLabs names.
  effective_tenancy_ocid = (
    var.tenancy_ocid != null && var.tenancy_ocid != "" ? var.tenancy_ocid :
    var.ociTenancyOcid != null && var.ociTenancyOcid != "" ? var.ociTenancyOcid :
    ""
  )
  effective_compartment_ocid = (
    var.compartment_ocid != null && var.compartment_ocid != "" ? var.compartment_ocid :
    var.ociCompartmentOcid != null && var.ociCompartmentOcid != "" ? var.ociCompartmentOcid :
    ""
  )
  effective_region = (
    var.region != null && var.region != "" ? var.region :
    var.ociRegionIdentifier != null && var.ociRegionIdentifier != "" ? var.ociRegionIdentifier :
    "us-ashburn-1"
  )

  # Use resId for unique resource naming across LiveLabs sandboxes
  res_suffix  = var.resId != "" ? var.resId : "dev"
  bucket_name = "hol-data-${local.res_suffix}-${random_string.deploy_id.result}"
}

# Randoms
resource "random_string" "deploy_id" {
  length  = 8
  special = false
}
