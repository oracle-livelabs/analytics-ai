# -----------------------------------------------------------------------------
# HOL Provisioning — AI Lakehouse Autonomous Database + Data Setup
#
# This file handles:
#   1. Create an AI Lakehouse Autonomous Database (2 ECPU, 1 TB)
#   2. Generate a wallet for SQLcl connectivity
#   3. Create the CONSTRUCTION_ENGINEERING schema (user + grants, as ADMIN)
#   4. Create tables (as CONSTRUCTION_ENGINEERING)
#   5. Load sample data (as CONSTRUCTION_ENGINEERING)
#
# The AIDP Workbench (in aidp.tf) depends on this pipeline completing.
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# 1. AI Lakehouse Autonomous Database
# -----------------------------------------------------------------------------
resource "oci_database_autonomous_database" "construction_engineering" {
  compartment_id           = local.effective_compartment_ocid
  display_name             = "hol-consteng-${local.res_suffix}-${random_string.deploy_id.result}"
  db_name                  = "holce${random_string.deploy_id.result}"
  db_workload              = "DW"
  db_version               = "26ai"
  compute_model            = "ECPU"
  compute_count            = 2
  data_storage_size_in_tbs = 1
  admin_password           = random_password.adb_admin.result
  is_auto_scaling_enabled  = false
  license_model            = "LICENSE_INCLUDED"

  freeform_tags = {
    project = "hol"
    managed = "terraform"
    res_id  = local.res_suffix
  }
}

# -----------------------------------------------------------------------------
# 2. Generate Wallet + Write Connection Details
# -----------------------------------------------------------------------------
resource "null_resource" "generate_wallet" {
  triggers = {
    adb_id = oci_database_autonomous_database.construction_engineering.id
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    environment = {
      ADB_OCID   = oci_database_autonomous_database.construction_engineering.id
      ADB_DBNAME = oci_database_autonomous_database.construction_engineering.db_name
      OUTPUT_DIR = "${path.module}/db_scripts"
      ADB_PASSWORD = nonsensitive(random_password.adb_admin.result)
    }
    command = <<-SCRIPT
      echo "============================================================"
      echo "  Generating ADB Wallet"
      echo "============================================================"
      echo "  ADB OCID: $ADB_OCID"
      echo "  DB Name:  $ADB_DBNAME"

      mkdir -p "$OUTPUT_DIR"

      oci db autonomous-database generate-wallet \
        --autonomous-database-id "$ADB_OCID" \
        --password "$ADB_PASSWORD" \
        --generate-type SINGLE \
        --file "$OUTPUT_DIR/wallet.zip"

      if [ ! -f "$OUTPUT_DIR/wallet.zip" ]; then
        echo "ERROR: Wallet generation failed"
        exit 1
      fi
      echo "  Wallet saved to $OUTPUT_DIR/wallet.zip"

      # Extract the _high TNS alias from the wallet
      TNS_ALIAS=$(python3 -c "
import zipfile, re
with zipfile.ZipFile('$OUTPUT_DIR/wallet.zip') as zf:
    tns = zf.read('tnsnames.ora').decode('utf-8')
    m = re.search(r'^(\S+_high)\s*=', tns, re.MULTILINE)
    print(m.group(1) if m else '$${ADB_DBNAME}_high')
" 2>/dev/null) || TNS_ALIAS="$${ADB_DBNAME}_high"

      # Write connection details for subsequent steps
      OUTPUT_JSON="$OUTPUT_DIR/aidp_adb.json"
      echo "{" > "$OUTPUT_JSON"
      echo "  \"adb_ocid\": \"$ADB_OCID\"," >> "$OUTPUT_JSON"
      echo "  \"db_name\": \"$ADB_DBNAME\"," >> "$OUTPUT_JSON"
      echo "  \"tns_alias\": \"$TNS_ALIAS\"," >> "$OUTPUT_JSON"
      echo "  \"wallet_path\": \"$OUTPUT_DIR/wallet.zip\"" >> "$OUTPUT_JSON"
      echo "}" >> "$OUTPUT_JSON"

      echo "  TNS Alias: $TNS_ALIAS"
      echo "  Connection details written to $OUTPUT_JSON"
    SCRIPT
  }

  depends_on = [
    oci_database_autonomous_database.construction_engineering,
  ]
}

# -----------------------------------------------------------------------------
# 3. Create CONSTRUCTION_ENGINEERING Schema (as ADMIN)
# -----------------------------------------------------------------------------
resource "null_resource" "create_schema" {
  triggers = {
    adb_id      = oci_database_autonomous_database.construction_engineering.id
    script_hash = filesha256("${path.module}/db_scripts/00_create_schema.sql")
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    environment = {
      ADB_PASSWORD = nonsensitive(random_password.adb_admin.result)
      SCRIPTS_DIR  = "${path.module}/db_scripts"
    }
    command = <<-SCRIPT
      ADB_JSON="$SCRIPTS_DIR/aidp_adb.json"
      if [ ! -f "$ADB_JSON" ]; then
        echo "ERROR: $ADB_JSON not found — generate_wallet may have failed"
        exit 1
      fi

      TNS_ALIAS=$(python3 -c "import json; print(json.load(open('$ADB_JSON'))['tns_alias'])")
      WALLET_PATH=$(python3 -c "import json; print(json.load(open('$ADB_JSON'))['wallet_path'])")

      echo "Running 00_create_schema.sql as ADMIN against $TNS_ALIAS..."
      sql -cloudconfig "$WALLET_PATH" "admin/$ADB_PASSWORD@$TNS_ALIAS" @"$SCRIPTS_DIR/00_create_schema.sql" "$ADB_PASSWORD"
    SCRIPT
  }

  depends_on = [
    null_resource.generate_wallet,
  ]
}

# -----------------------------------------------------------------------------
# 4. Create Tables (as CONSTRUCTION_ENGINEERING)
# -----------------------------------------------------------------------------
resource "null_resource" "create_tables" {
  triggers = {
    adb_id      = oci_database_autonomous_database.construction_engineering.id
    script_hash = filesha256("${path.module}/db_scripts/01_create_tables.sql")
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    environment = {
      ADB_PASSWORD = nonsensitive(random_password.adb_admin.result)
      SCRIPTS_DIR  = "${path.module}/db_scripts"
    }
    command = <<-SCRIPT
      ADB_JSON="$SCRIPTS_DIR/aidp_adb.json"
      if [ ! -f "$ADB_JSON" ]; then
        echo "ERROR: $ADB_JSON not found — generate_wallet may have failed"
        exit 1
      fi

      TNS_ALIAS=$(python3 -c "import json; print(json.load(open('$ADB_JSON'))['tns_alias'])")
      WALLET_PATH=$(python3 -c "import json; print(json.load(open('$ADB_JSON'))['wallet_path'])")

      echo "Running 01_create_tables.sql as CONSTRUCTION_ENGINEERING against $TNS_ALIAS..."
      sql -cloudconfig "$WALLET_PATH" "construction_engineering/$ADB_PASSWORD@$TNS_ALIAS" @"$SCRIPTS_DIR/01_create_tables.sql"
    SCRIPT
  }

  depends_on = [
    null_resource.create_schema,
  ]
}

# -----------------------------------------------------------------------------
# 5. Load Data (as CONSTRUCTION_ENGINEERING)
# -----------------------------------------------------------------------------
resource "null_resource" "load_data" {
  triggers = {
    adb_id      = oci_database_autonomous_database.construction_engineering.id
    script_hash = filesha256("${path.module}/db_scripts/02_load_data.sql")
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    environment = {
      ADB_PASSWORD = nonsensitive(random_password.adb_admin.result)
      SCRIPTS_DIR  = "${path.module}/db_scripts"
    }
    command = <<-SCRIPT
      ADB_JSON="$SCRIPTS_DIR/aidp_adb.json"
      if [ ! -f "$ADB_JSON" ]; then
        echo "ERROR: $ADB_JSON not found — generate_wallet may have failed"
        exit 1
      fi

      TNS_ALIAS=$(python3 -c "import json; print(json.load(open('$ADB_JSON'))['tns_alias'])")
      WALLET_PATH=$(python3 -c "import json; print(json.load(open('$ADB_JSON'))['wallet_path'])")

      echo "Running 02_load_data.sql as CONSTRUCTION_ENGINEERING against $TNS_ALIAS..."
      sql -cloudconfig "$WALLET_PATH" "construction_engineering/$ADB_PASSWORD@$TNS_ALIAS" @"$SCRIPTS_DIR/02_load_data.sql"
    SCRIPT
  }

  depends_on = [
    null_resource.create_tables,
  ]
}
