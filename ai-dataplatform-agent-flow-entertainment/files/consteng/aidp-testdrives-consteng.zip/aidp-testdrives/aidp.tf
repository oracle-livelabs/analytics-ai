# -----------------------------------------------------------------------------
# HOL Provisioning — AI Data Platform Workbench
#
# Creates the AIDP Workbench instance after the AI Lakehouse ADB has been
# provisioned and populated with construction engineering data (database.tf).
#
# The AIDP Workbench will use the existing ALH Autonomous Database in the
# same compartment.
# -----------------------------------------------------------------------------

resource "oci_ai_data_platform_ai_data_platform" "workshop" {
  compartment_id = local.effective_compartment_ocid
  display_name   = "hol-workshop-${local.res_suffix}-${random_string.deploy_id.result}"

  freeform_tags = {
    project = "hol"
    managed = "terraform"
    res_id  = local.res_suffix
  }

  timeouts {
    create = "90m"
    delete = "60m"
  }

  # Wait for the ALH ADB to be fully provisioned and populated before
  # creating the AIDP instance so it can discover the existing database.
  depends_on = [
    null_resource.load_data,
  ]
}

# -----------------------------------------------------------------------------
# Assign LiveLabs User to AI_DATA_PLATFORM_ADMIN Role
#
# AIDP has its own RBAC system separate from OCI IAM. Even with OCI IAM
# policies granting access, the user MUST also be assigned an AIDP role.
# Without this, the user gets RBAC 404 errors in the Workbench.
# -----------------------------------------------------------------------------
resource "null_resource" "assign_admin_role" {
  count = var.ociUserOcid != "" ? 1 : 0

  triggers = {
    instance_id = oci_ai_data_platform_ai_data_platform.workshop.id
    user_ocid   = var.ociUserOcid
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-c"]
    environment = {
      AIDP_INSTANCE_ID = oci_ai_data_platform_ai_data_platform.workshop.id
      REGION           = local.effective_region
      USER_OCID        = var.ociUserOcid
    }
    command = <<-SCRIPT
      set +e

      echo "============================================================"
      echo "  Assigning AIDP ADMIN Role"
      echo "============================================================"
      echo "  User OCID: $USER_OCID"

      BASE_URL="https://aidp.$REGION.oci.oraclecloud.com/20240831/dataLakes/$AIDP_INSTANCE_ID"

      # ------------------------------------------------------------------
      # Step 1: Assign user to AI_DATA_PLATFORM_ADMIN role
      # ------------------------------------------------------------------
      echo ""
      echo "[Step 1/2] Assigning AI_DATA_PLATFORM_ADMIN role..."

      ROLE_RESPONSE=$(oci raw-request \
        --http-method POST \
        --target-uri "$BASE_URL/roles/AI_DATA_PLATFORM_ADMIN/actions/addMember" \
        --request-body "{\"assignees\": [{\"target\": \"$USER_OCID\", \"type\": \"USER\"}]}" \
        2>&1) || true

      if echo "$ROLE_RESPONSE" | grep -q '"status": 2'; then
        echo "  Role assigned successfully"
      elif echo "$ROLE_RESPONSE" | grep -q '409'; then
        echo "  User already has ADMIN role — skipping"
      else
        echo "  WARNING: Unexpected response:"
        echo "  $ROLE_RESPONSE" | head -10
        echo "  Continuing to RBAC verification..."
      fi

      # ------------------------------------------------------------------
      # Step 2: Wait for RBAC propagation
      #
      # AIDP RBAC grants are not instant. Poll list_workspaces (an
      # RBAC-gated call) until it succeeds, confirming the role is active.
      # ------------------------------------------------------------------
      echo ""
      echo "[Step 2/2] Verifying RBAC propagation..."

      MAX_ATTEMPTS=24
      ATTEMPT=0
      while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
        RBAC_CHECK=$(oci raw-request \
          --http-method GET \
          --target-uri "$BASE_URL/workspaces" \
          2>&1) || true

        if echo "$RBAC_CHECK" | grep -q '"status": 2'; then
          echo "  ADMIN role confirmed active"
          break
        fi

        if echo "$RBAC_CHECK" | grep -qi 'RBAC'; then
          ATTEMPT=$((ATTEMPT + 1))
          if [ $((ATTEMPT % 6)) -eq 0 ]; then
            echo "  RBAC not yet active, waiting... ($((ATTEMPT * 5))s elapsed)"
          fi
          sleep 5
        else
          # Non-RBAC response — role is effective, proceed
          echo "  ADMIN role verification complete"
          break
        fi
      done

      if [ $ATTEMPT -ge $MAX_ATTEMPTS ]; then
        echo "  WARNING: RBAC propagation timed out after 2 min"
        echo "  The user may need to wait before accessing the Workbench"
      fi

      echo ""
      echo "============================================================"
      echo "  AIDP ADMIN Role Assignment Complete"
      echo "============================================================"
    SCRIPT
  }

  depends_on = [
    oci_ai_data_platform_ai_data_platform.workshop,
  ]
}

# -----------------------------------------------------------------------------
# Outputs
# -----------------------------------------------------------------------------
output "aidp_instance_id" {
  description = "OCID of the AIDP Workbench instance"
  value       = oci_ai_data_platform_ai_data_platform.workshop.id
}

output "aidp_instance_display_name" {
  description = "Display name of the AIDP Workbench instance"
  value       = oci_ai_data_platform_ai_data_platform.workshop.display_name
}

output "aidp_instance_state" {
  description = "Lifecycle state of the AIDP Workbench instance"
  value       = oci_ai_data_platform_ai_data_platform.workshop.state
}
